Just create an account on MongoDB Atlas and add your connection string in bscfg/mods/DB_Manager.py

The scripts are completely Open Sourced now, ENJOY! :)
