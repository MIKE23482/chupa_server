# -*- coding: utf-8 -*-
import socket
import os
config['partyName'] = u'\U0001F94Achupa el perro SMASHING\U0001F90D'
config['sessionType'] = 'ffa'
config['maxPartySize'] = 15
config['playlistCode'] = 456245
config['telnetPassword'] = ''
config['statsURL'] = 'https://discord.com/invite/ZFDc7zn8sb'
config['partyIsPublic'] = True
config['port'] = 43212

config['admin_id'] = 'pb-IF4hU0wPMA=='
config['host'] = 'MIKE'

config['show_rank'] = True
config['show_hp'] = False
config['show_texts'] = False
config['modded_powerups'] = False
config['show_powerup_name'] = True
config['floating_landmine'] = False
config['snowfall'] = False
config['extra_sparkles'] = False
config['earned_msg'] = True
config['show_tag'] = True
config['whitelist'] = False
config['interactive_powerups'] = True
config['logic_team_settings'] = False
config['custom_tnt'] = False
config['translator'] = True
config['transition_light_color'] = False
config['bomb_light'] = False
config['default_game_time_limit'] = 2









