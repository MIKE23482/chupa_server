import bs
import bsInternal
from random import randrange
correctAnswer = None
answeredBy = None

enableCoinsystem = True
questionDelay = 60 # segundos
questionsList = {
    'que es LGTBQ?': 'una idiotez', 'Quien es el quien pierde dignidad por una mujer que no le hace caso?': 'simp', 'La empresa que vende articuldos y repuestos del hogar?': 'the home deport', 'cuales son los 2 unicos generos?': 'hombre y mujer',
    'add':None,
    'multiply':None,
}


def askQuestion():
    global answeredBy
    global correctAnswer
    keys = []
    for x in questionsList:
        keys.append(x)

    question = keys[randrange(len(keys))]
    correctAnswer = questionsList[question]
    if question == 'add':
        a = randrange(100, 999)
        b = randrange(10, 99)
        correctAnswer = str(a + b)
        question = 'Cuanto es ' + str(a) + ' + ' + str(b) + '?'
    elif question == 'multiply':
        a = randrange(100, 999)
        availableB = [0, 1, 10, 5]
        b = availableB[randrange(4)]
        correctAnswer = str(a * b)
        question = 'Cuanto es ' + str(a) + ' x ' + str(b) + '?'
    bsInternal._chatMessage(question)
    answeredBy = None
    return


def checkAnswer(msg, clientID):
    global answeredBy
    if True:#msg.lower() == correctAnswer:
        if answeredBy is not None:
            bs.screenMessage('Respondido por ' + answeredBy, color=(1, 1, 1), transient=True, clients=[clientID])
        else:
            for i in bsInternal._getForegroundHostActivity().players:
                if i.getInputDevice().getClientID() == clientID:
                    answeredBy = i.getName()
                    accountID = i.get_account_id()
		    bs.screenMessage(answeredBy + ': ' + msg,color = (0,0.6,0.2),transient=True)
            try:
                bs.screenMessage('Felicidades' + answeredBy + '! Ganaste ' + bs.getSpecialChar('ticket') + '20.', color=(0, 0.6, 0.2), transient=True, clients=[clientID])
                addCoins(accountID, 20)
            except:
                pass

    '''else:
        bs.screenMessage('Wrong', color=(1, 0, 0), transient=True, clients=[clientID])'''
    return


def addCoins(accountID, amount):
    import DB_Manager as db
    # obten lo datos del jugador
    stats = db.getData(accountID)
    # sumamos el monto a su cuenta
    stats['p'] += amount
    # luego lo guardamos <:
    db.saveData(accountID, stats)


if enableCoinsystem: 
	timer = bs.Timer(questionDelay * 1000, askQuestion, timeType='real', repeat=True)
	# print 'Coin system loaded...'


