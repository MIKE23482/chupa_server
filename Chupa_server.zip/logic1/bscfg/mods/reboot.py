import bs
import bsInternal
import urllib2
import bsUtils
import DB_Manager

try:
    req = urllib2.Request('http://icanhazip.com', data=None)
    response = urllib2.urlopen(req, timeout=5)
    ip = str(bs.uni(response.read())).rstrip()
except:
    ip = 'Failed To Fetch IP'
port = str(bs.getConfig().get('Port', 43210))


def restart():
    bs.screenMessage(bs.Lstr(resource='internal.serverRestartingText'), transient=True)
    text = 'IP: %s  Port: %s' % (ip, port)
    bsInternal._chatMessage(text)
    bs.realTimer(2500, bs.Call(bs.quit))


bs.realTimer(3 * 60 * 60 * 1000, restart)


def warn():
    bs.screenMessage('The server will restart soon.', transient=True)


bs.realTimer((3 * 60 * 60 * 1000) - 900000, warn)
