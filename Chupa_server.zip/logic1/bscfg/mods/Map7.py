
import bs
from bsMap import Map, registerMap
import bsUtils
import random
import bdUtils

class Map7:
    points = {}
    boxes = {}
    boxes['areaOfInterestBounds'] = (0.3544110667, -1.493562578, -2.518391331) + (0.0, -15.0, 0.0) + (16.64754831, 15.06138989, 18.5029888)
    points['ffaSpawn1'] = (-10,-2,-3) + (0.1,0.1,1.0)
    points['ffaSpawn2'] = (9,-2,-3) + (0.1,0.1,1.0)
    points['ffaSpawn3'] = (-10,-2,-6.0) + (0.1,0.1,1.0) 
    points['ffaSpawn4'] = (9,-2,0.0) + (0.1,0.1,1.0)
    points['ffaSpawn5'] = (9,-2,-6.0) + (0.1,0.1,1.0)
    points['ffaSpawn6'] = (-10,-2,0.0) + (0.1,0.1,1.0)
    points['flag1'] = (-7.026110145, 4.308759233,5.6)
    points['flag2'] = (7.632557137, 4.366002373, -6.287969342)
    points['flagDefault'] = (0.4611826686, 4.382076338, 3.680881802)
    boxes['levelBounds'] = (0.0, 0.7956858119, -0.4689020853) + (0.0, 0.0, 0.0) + (35.16182389, 12.18696164, 21.52869693)
    points['powerupSpawn1'] = (-8.166594349, 5.281834349, -6.427493781)
    points['powerupSpawn2'] = (8.426873526, 5.342460464, -6.329745237)
    points['powerupSpawn3'] = (-8.201686731, 5.123385835, 0.4400721376)
    points['powerupSpawn4'] = (8.758924722, 5.123385835, 0.3494054559)
    points['shadowLowerBottom'] = (-0.2912522507, 2.020798381, 5.341226521)
    points['shadowLowerTop'] = (-0.2912522507, 3.206066063, 5.341226521)
    points['shadowUpperBottom'] = (-0.2912522507, 6.062361813, 5.341226521)
    points['shadowUpperTop'] = (-0.2912522507, 9.827201965, 5.341226521)
    points['spawn1'] = (-9,0.5,-3) + (1.0,0.1,1.0)
    points['spawn2'] = (9,0.5,-3) + (1.0,0.1,1.0)
    points['tnt1'] = (0.4599593402, 4.044276501, -6.573537395)
##Create Empty Map
class Map7(Map):
    from Map7 import Map7 as defs
    name = '2fort'
    playTypes = ['test', 'melee']

    @classmethod
    def getPreviewTextureName(cls):
        return 'rampageBGColor'

    @classmethod
    def onPreload(cls):
        data = {}
        data['model'] = bs.getModel('thePadLevel')
        data['modelBottom'] = bs.getModel('thePadLevelBottom')
        data['modelBG'] = bs.getModel('tipTopBG')
        #data['bgVRFillModel'] = bs.getModel('natureBackgroundVRFill')
        data['collideModel'] = bs.getCollideModel('thePadLevelCollide')
        data['tex'] = bs.getTexture('thePadLevelColor')
        data['modelBGTex'] = bs.getTexture('graphicsIcon')
        #data['collideBG'] = bs.getCollideModel('natureBackgroundCollide')
        data['railingCollideModel'] = bs.getCollideModel('thePadLevelBumper')
        #data['bgMaterial'] = bs.Material()
        #data['bgMaterial'].addActions(actions=('modifyPartCollision',
                                               #'friction', 10.0))
        return data

    def __init__(self):
        Map.__init__(self)
        self.locs=[]
        self.regions=[]
        self.explo=[]
        self.collision = bs.Material()
        self.collision.addActions(
            actions=(('modifyPartCollision', 'collide', True)))

        self.foo = bs.newNode('terrain', attrs={
            'model':self.preloadData['modelBG'],
            'lighting':False,
            'reflection':'powerup',
            'reflectionScale':[1],
            'colorTexture':self.preloadData['modelBGTex']})
        # self.bottom = bs.newNode('terrain', attrs={
        #     'model':self.preloadData['modelBottom'],
        #     'lighting':False,
        #     'colorTexture':self.preloadData['tex']})
        # bs.newNode('terrain', attrs={
        #     'model':self.preloadData['bgVRFillModel'],
        #     'lighting':False,
        #     'vrOnly':True,
        #     'background':True,
        #     #'colorTexture':self.preloadData['modelBGTex']})
        # self.bgCollide = bs.newNode('terrain', attrs={
        #     'collideModel':self.preloadData['collideBG'],
        #     'materials':[bs.getSharedObject('footingMaterial'),
        #                  self.preloadData['bgMaterial'],
        #                  bs.getSharedObject('deathMaterial')]})
        # self.railing = bs.newNode('terrain', attrs={
        #     'collideModel':self.preloadData['railingCollideModel'],
        #     'materials':[bs.getSharedObject('railingMaterial')],
        #     'bumper':True})
        possDict = [
                   {'pos': (-3,-3.0,-3.0),'size': (6.0,1.0,6.0)},
                   {'pos': (3,-3.0,-3.0),'size': (6.0,1.0,6.0)}

                
             
        ]
        for a, map in enumerate(possDict):
            self.locs.append(bs.newNode('locator',
                attrs={'shape': 'box',
                       'position': possDict[a]['pos'],
                       'color': (0.0, 6, 0),
                       'opacity': 0.1,
                       'drawBeauty': True,
                       'size': possDict[a]['size'],
                       'additive': False}))
            self.regions.append(bs.newNode('region',
                attrs={'scale': tuple(possDict[a]['size']),
                       'type': 'box',
                       'materials': [self.collision, bs.getSharedObject('footingMaterial')]}))
            self.locs[-1].connectAttr('position', self.regions[-1], 'position')

        posDict = [
                   {'pos': (-10,-3.0,-2.0),'size': (6.0,1.0,18.0)},
                   {'pos': (10,-3.0,-2.0),'size': (6.0,1.0,18.0)}

                
             
        ]
        for a, map in enumerate(posDict):
            self.locs.append(bs.newNode('locator',
                attrs={'shape': 'box',
                       'position': posDict[a]['pos'],
                       'color': (2, 0.0, 2),
                       'opacity': 0.1,
                       'drawBeauty': True,
                       'size': posDict[a]['size'],
                       'additive': False}))
            self.regions.append(bs.newNode('region',
                attrs={'scale': tuple(posDict[a]['size']),
                       'type': 'box',
                       'materials': [self.collision, bs.getSharedObject('footingMaterial')]}))
            self.locs[-1].connectAttr('position', self.regions[-1], 'position')
        
        g = bs.getSharedObject('globals')
        g.tint = (1,1,1)
        g.ambientColor = (1.3, 1.2, 1.0)
        g.vignetteOuter = (0.57, 0.57, 0.57)
        g.vignetteInner = (0.9, 0.9, 0.9)
        g.vrCameraOffset = (0, -0.8, -1.1)
        g.vrNearClip = 0.5

        def path():
                p = bs.newNode('prop', attrs={'position':"position",'body':'sphere','model':bs.getModel('bomb'),'colorTexture':bs.getTexture('logo'),'bodyScale':25.0,'reflection': 'powerup', 'density':999999999999999999999*99999999999999,'damping':999999999999999999999*99999999999999,'reflectionScale': [1.0],'modelScale':25.0,'gravityScale':50,'shadowSize':0.0,'materials':[bs.getSharedObject('footingMaterial'),bs.getSharedObject('footingMaterial')]})
                bsUtils.animateArray(p,"position",3,{0:(-25.830377363, -10.228850685, -12.803988636),60000:(20.148493267, -10.429165244, -12.588618549),110000:(-20.830377363, -15.228850685, -12.803988636),117000:(-20.830377363, -15.228850685, -12.803988636),121500:(-2.830377363, -20.228850685, -5.803988636),122500:(0.830377363, 3.228850685, 0.803988636)},loop = True)                
        bs.gameTimer(100,bs.Call(path))

        m = 7
        s = 2000
        bsUtils.animateArray(bs.getSharedObject('globals'), 'ambientColor', 3, {0: (1 * m, 0, 0), s: (0, 1 * m, 0), s * 2: (0, 0, 1 * m), s * 3: (1 * m, 0, 0)}, True)
          

        t = bs.newNode('text', attrs={
            'text':'Mapa hecho por ROUSS RRMX <3',
            'scale':0.5,
            'maxWidth':0,
            'position':(-500,10),
            'shadow':0.5,
            'flatness':0.5,
            'hAlign':'center',
            'vAttach':'bottom'})

registerMap(Map7)