#PCMODDER ~ AVAROHANA
#
#seperated the mighty fire.py
#now contains a few basic server settings
#
#
whitelist = False
#
spamProtection = True
#
flashFloat = False
#
muteAll = False
#
auto_night = True
#
stats_shower = True
#
pcfloater = True
#
authentication = False
#
welcome_msg = u'\ue043 Bienvenido al Servidor de Mikee!\ue043'
#
tell_time = True
#
floater = True
#