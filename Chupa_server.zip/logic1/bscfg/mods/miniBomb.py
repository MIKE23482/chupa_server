from bsSpaz import Appearance


t = Appearance("mini Bomb")
#texture 1
t.colorTexture = "bombColor"
t.colorMaskTexture = "bombColor"
#nose jaja 
t.defaultColor = (0.2,0.8,0.8)
#t.defaultHighlight = (0.2,0.8,0.8)
#texture 2
t.iconTexture = "heart"
t.iconMaskTexture = "heart"
#Cuerpo
t.headModel =     "bunnyPelvis"
t.torsoModel =    "bomb"
t.pelvisModel =   "bunnyPelvis"
t.upperArmModel = "bunnyPelvis"
t.foreArmModel =  "aliForeArm"
t.handModel =     "aliHand"
t.upperLegModel = "wizardUpperLeg"
t.lowerLegModel = "wizardUpperLeg"
t.toesModel =     "neoSpazToes"
#Sonidos
t.attackSounds = ['bombDrop01']
t.jumpSounds = ['penguin1']
t.impactSounds = ["penguinHit2"]
t.deathSounds=['explosion04']
t.pickupSounds = ['ooh']
t.fallSounds=["boo"]

t.style = 'bones'  
#crado por jhoel