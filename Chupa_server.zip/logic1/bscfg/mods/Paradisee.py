#by :bombsquad_moding
import bsMap
from bsMap import *
import bsInternal
		
class Paradisee:
	points = {}
	boxes = {}
	boxes['areaOfInterestBounds'] = (0.0, 1.185751251, 0.4326226188) + (0.0, 0.0, 0.0) + (29.8180273, 11.57249038, 18.89134176)
	boxes['edgeBox'] = (-0.103873591, 0.4133341891, 0.4294651013) + (0.0, 0.0, 0.0) + (22.48295719, 1.290242794, 8.990252454)
	points['ffaSpawn1'] = (-5,0,0)
	points['ffaSpawn2'] = (5.0,0,0)
	points['flag1'] = (11.20,6.80,0)
	points['flag2'] = (-11.20,4.80,0)
	points['flagDefault'] = (0,8,0)
	boxes['goal1'] = (12.22454533, 1.0, 0.1087926362) + (0.0, 0.0, 0.0) + (2.0, 2.0, 12.97466313)
	boxes['goal2'] = (-12.15961605, 1.0, 0.1097860203) + (0.0, 0.0, 0.0) + (2.0, 2.0, 13.11856424)
	boxes['levelBounds'] = (0.0, 1.185751251, 0.4326226188) + (0.0, 0.0, 0.0) + (42.09506485, 22.81173179, 29.76723155)
	points['powerupSpawn1'] = (-2.50,1,2.0)
	points['powerupSpawn2'] = (2.50,1,-2.0)
	points['powerupSpawn3'] = (-2.50,1,-2.0)
	points['powerupSpawn4'] = (2.50,1,2.0)
	points['tnt1'] = (0,4,0)
	points['spawn1'] = (11.20,4.80,0)
	points['spawn2'] = (9.823107149, 0.01092306765, 0.0) + (0.5, 1.0, 4.0)



#def LandMine_Up():
#    LandMine_Up=bs.newNode('prop', attrs={'position':(0, 0, 0),'velocity':(0,3,0),'sticky':False,'body':'landMine','model':bs.getModel('landMine'),'colorTexture':bs.getTexture('achievementWall'),'bodyScale':5.0,'reflection': 'powerup','density':9999999999999999999999999*99999999999999999,'reflectionScale': [1.0],'modelScale':5.0,'gravityScale':0,'shadowSize':0.0,'materials':[bs.getSharedObject('objectMaterial'),bs.getSharedObject('footingMaterial')]})
#    bs.gameTimer(1200,LandMine_Up.delete)





class Paradisee(Map):
    from Paradisee import Paradisee as defs
    name = "Paradisee"
    playTypes = ['melee', 'football', 'teamFlag', 'keepAway']

    @classmethod
    def getPreviewTextureName(cls):
        return 'bg'

    @classmethod
    def onPreload(cls):
        data = {}
        data['model'] = bs.getModel("actionHeroUpperArm")
        data['vrFillModel'] = bs.getModel('footballStadiumVRFill')
        data['collideModel'] = bs.getCollideModel("footballStadiumCollide")
        data['tex'] = bs.getTexture("tnt")
        data['bgModel'] = bs.getModel('thePadBG')
        data['bgTex'] = bs.getTexture('explosion')
        return data

    def __init__(self):
        Map.__init__(self)
        self.preloadData = self.preload(onDemand=True)
        
        def path():
                p = bs.newNode('prop', attrs={'position':"position",'body':'sphere','model':bs.getModel('bomb'),'colorTexture':bs.getTexture('logo'),'bodyScale':4.0,'reflection': 'powerup','density':9999999999999999,'reflectionScale': [1.0],'modelScale':4.0,'gravityScale':0,'shadowSize':0.0,'materials':[bs.getSharedObject('footingMaterial'),bs.getSharedObject('footingMaterial')]})
                bsUtils.animateArray(p,"position",3,{0:(1.830377363, 4.228850685, 3.803988636),10000:(4.148493267, 4.429165244, -6.588618549),20000:(-5.422572086, 4.228850685, 2.803988636),25000:(-6.859406739, 4.429165244, -6.588618549),30000:(-6.859406739, 4.429165244, -6.588618549),35000:(3.148493267, 4.429165244, -6.588618549),40000:(1.830377363, 4.228850685, 2.803988636),45000:(-5.422572086, 4.228850685, 2.803988636),50000:(-5.422572086, 4.228850685, 2.803988636),55000:(1.830377363, 4.228850685, 2.803988636),60000:(3.148493267, 4.429165244, -6.588618549),70000:(1.830377363, 4.228850685, 2.803988636),75000:(3.148493267, 4.429165244, -6.588618549),80000:(-5.422572086, 4.228850685, 2.803988636),90000:(-6.859406739, 4.429165244, -6.588618549),95000:(-6.859406739, 4.429165244, -6.588618549)},loop = True)                

        bs.gameTimer(100,bs.Call(path))
        self.powerup = bs.newNode('prop',
 attrs={'position':(-8.50, 1.20, 0),
  'velocity':(0,0,0),
  'model':bs.getModel('santaHead'),
  'modelScale':5.6,
  'bodyScale':5,
  'density':999999999999999999999*99999999999999,
  'damping':999999999999999999999*99999999999999,
  'gravityScale':0,
  'body':'crate',
  'reflection':'powerup',
  'reflectionScale':[0.3],									  
  'colorTexture':bs.getTexture('santaColor'),
  'materials':[bs.getSharedObject('footingMaterial')]})
        self.powerup = bs.newNode('prop',
 attrs={'position':(8.50, 1.20, 0),
  'velocity':(0,0,0),
  'model':bs.getModel('santaHead'),
  'modelScale':5.6,
  'bodyScale':5,
  'density':999999999999999999999*99999999999999,
  'damping':999999999999999999999*99999999999999,
  'gravityScale':0,
  'body':'crate',
  'reflection':'powerup',
  'reflectionScale':[0.3],									  
  'colorTexture':bs.getTexture('santaColor'),
  'materials':[bs.getSharedObject('footingMaterial')]})

        
        
        self.bg = bs.newNode('terrain',
                              attrs={'model':self.preloadData['bgModel'],
                                     'lighting':False,
                                     'background':True,
                                     'colorTexture':self.preloadData['bgTex']})
        
        
        self.node = bs.newNode('terrain', delegate=self, attrs={
            'model':self.preloadData['model'],        
            'collideModel':self.preloadData['collideModel'],
            'materials':[bs.getSharedObject('footingMaterial')]})
        bs.newNode('terrain',
                   attrs={'model':self.preloadData['vrFillModel'],
                          'lighting':False,
                          'vrOnly':True,
                          'background':True,
                          'colorTexture':self.preloadData['tex']})
        g = bs.getSharedObject('globals')
        g.tint = (1.0,1.0,1.0)
        g.ambientColor = (1.3, 1.2, 1.0)
        g.vignetteOuter = (0.57, 0.57, 0.57)
        g.vignetteInner = (0.9, 0.9, 0.9)
        g.vrCameraOffset = (0, -0.8, -1.1)
        g.vrNearClip = 0.5

    def _isPointNearEdge(self,p,running=False):
        boxPosition = self.defs.boxes['edgeBox'][0:3]
        boxScale = self.defs.boxes['edgeBox'][6:9]
        x = (p.x() - boxPosition[0])/boxScale[0]
        z = (p.z() - boxPosition[2])/boxScale[2]
        return (x < -0.5 or x > 0.5 or z < -0.5 or z > 0.5)
registerMap(Paradisee)