
import bs
from bsMap import Map, registerMap
import bsUtils
import random
class Map4:
    points = {}
    boxes = {}
    boxes['areaOfInterestBounds'] = (0.3544110667, 0.493562578, -2.518391331) + (0.0, -10.0, 0.0) + (16.64754831, 8.06138989, 18.5029888)
    points['ffaSpawn1'] = (-9,0.5,-3) + (1.0,0.1,5.0)
    points['ffaSpawn2'] = (9,0.5,-3) + (1.0,0.1,5.0)
    points['ffaSpawn3'] = (-6,0.5,-6.0) + (2.0,0.1,1.0) 
    points['ffaSpawn4'] = (6,0.5,0.0) + (2.0,0.1,1.0)
    points['ffaSpawn5'] = (6,0.5,-6.0) + (2.0,0.1,1.0)
    points['ffaSpawn6'] = (-6,0.5,0.0) + (2.0,0.1,1.0)
    points['flag1'] = (-7.026110145, 4.308759233,5.6)
    points['flag2'] = (7.632557137, 4.366002373, -6.287969342)
    points['flagDefault'] = (0.4611826686, 4.382076338, 3.680881802)
    boxes['levelBounds'] = (0.0, 0.7956858119, -0.4689020853) + (0.0, 0.0, 0.0) + (35.16182389, 12.18696164, 21.52869693)
    points['powerupSpawn1'] = (-4.166594349, 5.281834349, -6.427493781)
    points['powerupSpawn2'] = (4.426873526, 5.342460464, -6.329745237)
    points['powerupSpawn3'] = (-4.201686731, 5.123385835, 0.4400721376)
    points['powerupSpawn4'] = (4.758924722, 5.123385835, 0.3494054559)
    points['shadowLowerBottom'] = (-0.2912522507, 2.020798381, 5.341226521)
    points['shadowLowerTop'] = (-0.2912522507, 3.206066063, 5.341226521)
    points['shadowUpperBottom'] = (-0.2912522507, 6.062361813, 5.341226521)
    points['shadowUpperTop'] = (-0.2912522507, 9.827201965, 5.341226521)
    points['spawn1'] = (-9,0.5,-3) + (1.0,0.1,1.0)
    points['spawn2'] = (9,0.5,-3) + (1.0,0.1,1.0)
    points['tnt1'] = (0.4599593402, 4.044276501, -6.573537395)
##Create Empty Map
class Map4(Map):
    from Map4 import Map4 as defs
    name = 'New Map box'
    playTypes = ['test', 'melee']

    @classmethod
    def getPreviewTextureName(cls):
        return 'rampageBGColor'

    @classmethod
    def onPreload(cls):
        data = {}
        data['model'] = bs.getModel('thePadLevel')
        data['modelBottom'] = bs.getModel('thePadLevelBottom')
        data['modelBG'] = bs.getModel('thePadBG')
        #data['bgVRFillModel'] = bs.getModel('natureBackgroundVRFill')
        data['collideModel'] = bs.getCollideModel('thePadLevelCollide')
        data['tex'] = bs.getTexture('thePadLevelColor')
        data['modelBGTex'] = bs.getTexture('menuBG')
        #data['collideBG'] = bs.getCollideModel('natureBackgroundCollide')
        data['railingCollideModel'] = bs.getCollideModel('thePadLevelBumper')
        #data['bgMaterial'] = bs.Material()
        #data['bgMaterial'].addActions(actions=('modifyPartCollision',
                                               #'friction', 10.0))
        return data

    def __init__(self):
        Map.__init__(self)
        self.locs=[]
        self.regions=[]
        self.explo=[]
        self.collision = bs.Material()
        self.collision.addActions(
            actions=(('modifyPartCollision', 'collide', True)))

        self.foo = bs.newNode('terrain', attrs={
            'model':self.preloadData['modelBG'],
            'lighting':False,
            'colorTexture':self.preloadData['modelBGTex']})
        # self.bottom = bs.newNode('terrain', attrs={
        #     'model':self.preloadData['modelBottom'],
        #     'lighting':False,
        #     'colorTexture':self.preloadData['tex']})
        # bs.newNode('terrain', attrs={
        #     'model':self.preloadData['bgVRFillModel'],
        #     'lighting':False,
        #     'vrOnly':True,
        #     'background':True,
        #     #'colorTexture':self.preloadData['modelBGTex']})
        # self.bgCollide = bs.newNode('terrain', attrs={
        #     'collideModel':self.preloadData['collideBG'],
        #     'materials':[bs.getSharedObject('footingMaterial'),
        #                  self.preloadData['bgMaterial'],
        #                  bs.getSharedObject('deathMaterial')]})
        # self.railing = bs.newNode('terrain', attrs={
        #     'collideModel':self.preloadData['railingCollideModel'],
        #     'materials':[bs.getSharedObject('railingMaterial')],
        #     'bumper':True})

        posDict = [
                   {'pos': (-9,0.0,-3.0),'size': (3.0,1.0,14.0)},
                   {'pos' :(9,0.0,-3.0), 'size': (3.0,1.0,14.0)},
                   {'pos': (0.0,0.0,-6.0), 'size':(15.0,1.0,3.0)},
                   {'pos': (0.0,0.0,0.0), 'size': (15.0,1.0,3.0)},
                   {'pos': (0.0,0.0,-3.0), 'size': (3.0,1.0,3.0)},              
        ]
        for a, map in enumerate(posDict):
            self.locs.append(bs.newNode('locator',
                attrs={'shape': 'box',
                       'position': posDict[a]['pos'],
                       'color': (0.8, 0.8, 0.8),
                       'opacity': 0,
                       'drawBeauty': True,
                       'size': posDict[a]['size'],
                       'additive': False}))
            self.regions.append(bs.newNode('region',
                attrs={'scale': tuple(posDict[a]['size']),
                       'type': 'box',
                       'materials': [self.collision, bs.getSharedObject('footingMaterial')]}))
            self.locs[-1].connectAttr('position', self.regions[-1], 'position')



        g = bs.getSharedObject('globals')
        g.tint = (0.5,0.6,0.6)
        g.ambientColor = (1.3, 1.2, 1.0)
        g.vignetteOuter = (0.57, 0.57, 0.57)
        g.vignetteInner = (0.9, 0.9, 0.9)
        g.vrCameraOffset = (0, -0.8, -1.1)
        g.vrNearClip = 0.5
        tint = (0.3, 0.3, 0.3)
        self.color = (0.1, 0.1, 0.1)
        self._spazArray = []
        def Lights1():
            self.light1 = bs.newNode('light', attrs={
                'position': (random.randint(0, 9)-4,4.5,random.randint(0, 9)-4.5),
                'color': (random.random(),random.random(),random.random()),
                'volumeIntensityScale': 1.0,
                'radius': 0.4,
                'intensity': 9})

            bs.animate(self.light1, 'intensity',{0: self.light1.intensity, self.lightstimer: 0})

            def deleteLights():
                if self.light1.exists():
                    self.light1.delete()

            bs.gameTimer(self.lightstimer, deleteLights)

        def Lights2():
            self.light2 = bs.newNode('light', attrs={'position': (random.randint(0, 9)-4,4.5,random.randint(0, 9)-4),
                'color': (random.random(),random.random(),random.random()),
                'volumeIntensityScale': 1.0,
                'radius': 0.4,
                'intensity': 9})

            bs.animate(self.light2, 'intensity',{0: self.light2.intensity, self.lightstimer: 0})

            def deleteLights():
                    if self.light2.exists():
                        self.light2.delete()

            bs.gameTimer(self.lightstimer, deleteLights)
   
        def Lights3():
            self.light3 = bs.newNode('light', attrs={'position': (random.randint(0, 9)-4,4.5,random.randint(0, 9)-4),
                'color': (random.random(),random.random(),random.random()),
                'volumeIntensityScale': 1.0,
                'radius': 0.4,
                'intensity': 9})

            bs.animate(self.light3, 'intensity',{0: self.light3.intensity, self.lightstimer: 0})

            def deleteLights():
                if self.light3.exists():
                    self.light3.delete()

            bs.gameTimer(self.lightstimer, deleteLights)

        def LightsSlowshowTimer(on=True):
            if on:
                self.lightstimer = 1000
                self.lts1 = bs.gameTimer(1000, Lights1, repeat=True)

                def light2timer():
                    self.lts2 = bs.gameTimer(1000, Lights2, repeat=True)

                def light3timer():
                    self.lts3 = bs.gameTimer(1000, Lights3, repeat=True)

                    # start 2 light timer for look better
                self.lts2t1 = bs.gameTimer(300, light2timer)
                    # start 3 light timer for look better
                self.lts3t1 = bs.gameTimer(600, light3timer)
            else:
                self.lts1 = None
                self.lts2 = None
                self.lts3 = None
                self.lts2t1 = None
                self.lts3t1 = None
                if self.light1.exists():
                    self.light1.delete()

                if self.light2.exists():
                    self.light2.delete()

                if self.light3.exists():
                    self.light3.delete()

        def StrobeTimer(on=True):
            if on:
                self.light4 = bs.newNode('light', attrs={
                    'position': (0, 4.5, 0),
                    'color': (1, 1, 2),
                    'volumeIntensityScale': 1.0,
                    'radius': 10,
                    'intensity': 0.3})

                def switcher():
                    try:
                        self.light4.intensity = 0.3
                    except StandardError:
                        pass

                    def off():
                        try:
                            self.light4.intensity = 0
                        except StandardError:
                            pass

                    bs.gameTimer(40, off)

                self.ltstrobe = bs.gameTimer(80, switcher, repeat=True)
            else:
                self.ltstrobe = None
                if self.light4.exists():
                    self.light4.delete()

        def LightsFastshowTimer(on=True):
            if on:
                self.lightstimer = 400
                self.lt1 = bs.gameTimer(469, Lights1, repeat=True)
                self.lt2 = bs.gameTimer(469, Lights2, repeat=True)
                self.lt3 = bs.gameTimer(469, Lights3, repeat=True)

            else:
                self.lt1 = None
                self.lt2 = None
                self.lt3 = None
                if self.light1.exists():
                    self.light1.delete()

                if self.light2.exists():
                    self.light2.delete()

                if self.light3.exists():
                    self.light3.delete()
 
        def fadeOut():
            bs.animateArray(
                bsGlobals, 'vignetteInner', 3,
                {0: g.vignetteInner, 7000: (0, 0, 0)})

            bs.animateArray(
                bsGlobals, 'vignetteOuter', 3,
                {0: g.vignetteOuter, 7000: (0, 0, 0)})

            bs.animateArray(
                bsGlobals, 'tint', 3,
                {0: g.tint, 7000: (0, 0, 0)})

            self.lt1 = None
            self.lt2 = None
            self.lt3 = None
            self.lts1 = None
            self.lts2 = None
            self.lts3 = None
            self.lts2t1 = None
            self.lts3t1 = None
            if self.light1.exists():
                self.light1.delete()

            if self.light2.exists():
                self.light2.delete()

            if self.light3.exists():
                self.light3.delete()

        def intro():
            LightsSlowshowTimer()  

        def drop():
            self.jumping = True
            LightsSlowshowTimer(on=False)
            LightsFastshowTimer()
            StrobeTimer()

            def jump():
                s = int(random.random() * len(self._spazArray))
                self._spazArray[s].onJumpPress()
                self._spazArray[s].onJumpRelease()
                if self.jumping and not s == 40:
                    bs.gameTimer(50, bs.Call(jump))

            jump()

        def middle():
            self.jumping = False
            LightsSlowshowTimer()
            LightsFastshowTimer(on=False)
            StrobeTimer(on=False)

        intro()
        bs.gameTimer(35460, drop)
        bs.gameTimer(78620, middle)
        bs.gameTimer(128560, drop)
        bs.gameTimer(170000, middle)
        bs.gameTimer(175000, fadeOut)

        def dropBGD():
            pos = (-10 + (random.random()*25), 3.2,
                   -15 + (random.random()*25))

            bs.emitBGDynamics(
                position=pos,
                count=int(30 + random.random()*70),
                scale=1+random.random(),
                spread=15,
                chunkType='spark',
                emitType='stickers')

        bs.gameTimer(10, dropBGD, True)

        t = bs.newNode('text', attrs={
            'text':'Mapa hecho por ROUSS RRMX <3',
            'scale':0.5,
            'maxWidth':0,
            'position':(-500,10),
            'shadow':0.5,
            'flatness':0.5,
            'hAlign':'center',
            'vAttach':'bottom'})

registerMap(Map4)