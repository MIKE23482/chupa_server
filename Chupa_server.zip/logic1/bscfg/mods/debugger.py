import sys
import traceback
import some


class TracePrints(object):
    def __init__(self):
        self.stdout = sys.stdout

    def write(self):
        self.stdout.write('\n')
    def flush(self):
        pass


if some.debug:
    sys.stdout = TracePrints()
