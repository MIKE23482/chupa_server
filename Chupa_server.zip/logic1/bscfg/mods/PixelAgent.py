# coding=utf-8
from bsSpaz import *

##Created by AgentZn##################
t = Appearance("PixelAgent")

t.colorTexture = "agentColor"
t.colorMaskTexture = "agentColorMask"

t.defaultColor = (0.6,0.6,0.6)
t.defaultHighlight = (0,1,0)

t.iconTexture = "agentIcon"
t.iconMaskTexture = "pixieIconColorMask"

t.headModel = "pixieHead"
t.torsoModel = "agentTorso"
t.pelvisModel = "agentPelvis"
t.upperArmModel = "agentUpperArm"
t.foreArmModel = "agentForeArm"
t.handModel = "agentHand"
t.upperLegModel = "agentUpperLeg"
t.lowerLegModel = "agentLowerLeg"
t.toesModel = "agentToes"

agentSounds = ['agent1', 'agent2', 'agent3', 'agent4']
agentHitSounds = ['agentHit1', 'agentHit2']
t . attackSounds = agentSounds
t . jumpSounds = agentSounds
t . impactSounds = agentHitSounds
t . deathSounds = ["agentDeath"]
t . pickupSounds = agentSounds
t . fallSounds = ["agentFall"]
t . style = 'agent'