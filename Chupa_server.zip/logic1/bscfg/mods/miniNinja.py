from bsSpaz import Appearance


t = Appearance("minininja")
#texture 1
t.colorTexture = "ninjaColor"
t.colorMaskTexture = "ninjaColorMask"
#nose jaja 
t.defaultColor = (0.2,0.8,0.8)
#t.defaultHighlight = (0.2,0.8,0.8)
#texture 2
t.iconTexture = "ninjaIcon"
t.iconMaskTexture = "ninjaIconColorMask"
#Cuerpo
t.headModel =     "bunnyPelvis"
t.torsoModel =    "ninjaHead"
t.pelvisModel =   "bunnyPelvis"
t.upperArmModel = "bunnyPelvis"
t.foreArmModel =  "aliForeArm"
t.handModel =     "aliHand"
t.upperLegModel = "wizardUpperLeg"
t.lowerLegModel = "wizardUpperLeg"
t.toesModel =     "neoSpazToes"
#Sonidos
t.attackSounds = ['ninjaAttack1']  
t.jumpSounds = ['penguin1']
t.impactSounds = ["penguinHit2"]
t.deathSounds=['achievement']
t.pickupSounds = ['ooh']
t.fallSounds=["ninjaFall1"]

t.style = 'bones'  
#crado por jhoel
e = 'bones'  
#crado por jhoel