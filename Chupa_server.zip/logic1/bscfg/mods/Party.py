#by :bombsquad_moding
import bsMap
from bsMap import *
import bsInternal
		
class Party:
    points = {}
    boxes = {}
    boxes['areaOfInterestBounds'] = (0.3544110667, 4.493562578, -2.518391331) + (0.0, 0.0, 0.0) + (16.64754831, 8.06138989, 18.5029888)
    points['ffaSpawn1'] = (-3.812275836, 4.380655495, -8.962074979) + (2.371946621, 1.0, 0.8737798622)
    points['ffaSpawn2'] = (4.472503025, 4.406820459, -9.007239732) + (2.708525168, 1.0, 0.8737798622)
    points['ffaSpawn3'] = (6.972673935, 4.380775486, -7.424407061) + (0.4850648533, 1.0, 1.597018665)
    points['ffaSpawn4'] = (-6.36978974, 4.380775486, -7.424407061) + (0.4850648533, 1.0, 1.597018665)
    points['flag1'] = (-7.026110145, 4.308759233, -6.302807727)
    points['flag2'] = (7.632557137, 4.366002373, -6.287969342)
    points['flagDefault'] = (0.4611826686, 4.382076338, 3.680881802)
    boxes['levelBounds'] = (0.2608783669, 4.899663734, -3.543675157) + (0.0, 0.0, 0.0) + (29.23565494, 14.19991443, 29.92689344)
    points['powerupSpawn1'] = (-4.166594349, 5.281834349, -6.427493781)
    points['powerupSpawn2'] = (4.426873526, 5.342460464, -6.329745237)
    points['powerupSpawn4'] = (4.758924722, 5.123385835, 0.3494054559)
    points['shadowLowerBottom'] = (-0.2912522507, 2.020798381, 5.341226521)
    points['shadowLowerTop'] = (-0.2912522507, 3.206066063, 5.341226521)
    points['shadowUpperBottom'] = (-0.2912522507, 6.062361813, 5.341226521)
    points['shadowUpperTop'] = (-0.2912522507, 9.827201965, 5.341226521)
    points['spawn1'] = (-3.902942148, 4.380655495, -8.962074979) + (1.66339533, 1.0, 0.8737798622)
    points['spawn2'] = (4.775040345, 4.406820459, -9.007239732) + (1.66339533, 1.0, 0.8737798622)
    points['tnt1'] = (0.4599593402, 4.044276501, -6.573537395)

class Party(Map):
    from Party import Party as defs
    name = 'Party'
    playTypes = ['melee','keepAway','teamFlag','kingOfTheHill']

    @classmethod
    def getPreviewTextureName(cls):
        return 'thePadPreview'

    @classmethod
    def onPreload(cls):
        data = {}
        data['model'] = bs.getModel('thePadLevel')
        data['bottomModel'] = bs.getModel('thePadLevelBottom')
        data['collideModel'] = bs.getCollideModel('thePadLevelCollide')
        data['tex'] = bs.getTexture('thePadLevelColor')
        data['bgTex'] = bs.getTexture('logo')
        # fixme should chop this into vr/non-vr sections for efficiency
        data['bgModel'] = bs.getModel('thePadBG')
        data['railingCollideModel'] = bs.getCollideModel('thePadLevelBumper')
        data['vrFillMoundModel'] = bs.getModel('thePadVRFillMound')
        data['vrFillMoundTex'] = bs.getTexture('vrFillMound')
        return data

    def __init__(self):
        Map.__init__(self)
        self.powerup = bs.newNode('prop',
 attrs={'position':(-9.50, 2.40, -3),
  'velocity':(0,0,0),
  'model':bs.getModel('powerup'),
  'modelScale':5.6,
  'bodyScale':5,
  'density':999999999999999999999*99999999999999,
  'damping':999999999999999999999*99999999999999,
  'gravityScale':0,
  'body':'crate',
  'reflection':'powerup',
  'reflectionScale':[0.3],                                    
  'colorTexture':random.choice([bs.getTexture('powerupImpactBombs'),bs.getTexture('logo'),bs.getTexture('penguinIcon'),bs.getTexture('pixieIcon'),bs.getTexture('powerupStickyBombs'),bs.getTexture('storeIcon'),bs.getTexture('bonesIcon'),bs.getTexture('ouyaOButton')]),
  'materials':[bs.getSharedObject('footingMaterial')]})
        self.powerup = bs.newNode('prop',
  attrs={'position':(9.6, 2.40,-3),
  'velocity':(0,0,0),
  'model':bs.getModel('powerup'),
  'modelScale':5.6,
  'bodyScale':5,
  'density':999999999999999999999*99999999999999,
  'damping':999999999999999999999*99999999999999,
  'gravityScale':0,
  'body':'crate',
  'reflection':'powerup',
  'reflectionScale':[0.3],                                    
  'colorTexture':random.choice([bs.getTexture('powerupImpactBombs'),bs.getTexture('logo'),bs.getTexture('penguinIcon'),bs.getTexture('pixieIcon'),bs.getTexture('powerupStickyBombs'),bs.getTexture('storeIcon'),bs.getTexture('bonesIcon'),bs.getTexture('ouyaOButton')]),
  'materials':[bs.getSharedObject('footingMaterial')]})
        self.node = bs.newNode('terrain', delegate=self, attrs={
            'collideModel':self.preloadData['collideModel'],
            'model':self.preloadData['model'],
            'colorTexture':self.preloadData['tex'],
            'materials':[bs.getSharedObject('footingMaterial')]})
        self.foo = bs.newNode('terrain', attrs={
            'model':self.preloadData['bgModel'],
            'lighting':False,
            'background':True,
            'colorTexture':self.preloadData['bgTex']})
        self.railing = bs.newNode('terrain', attrs={
            'collideModel':self.preloadData['railingCollideModel'],
            'materials':[bs.getSharedObject('railingMaterial')],
            'bumper':True})
        bs.newNode('terrain', attrs={
            'model':self.preloadData['vrFillMoundModel'],
            'lighting':False,
            'vrOnly':True,
            'color':(0.56,0.55,0.47),
            'background':True,
            'colorTexture':self.preloadData['vrFillMoundTex']})

        g = bs.getSharedObject('globals')
        g.tint = (0.5,0.6,0.6)
        g.ambientColor = (1.3, 1.2, 1.0)
        g.vignetteOuter = (0.57, 0.57, 0.57)
        g.vignetteInner = (0.9, 0.9, 0.9)
        g.vrCameraOffset = (0, -0.8, -1.1)
        g.vrNearClip = 0.5
        tint = (0.3, 0.3, 0.3)
        self.color = (0.1, 0.1, 0.1)
        self._spazArray = []
        def Lights1():
            self.light1 = bs.newNode('light', attrs={
                'position': (random.randint(0, 9)-4,4.5,random.randint(0, 9)-4.5),
                'color': (random.random(),random.random(),random.random()),
                'volumeIntensityScale': 1.0,
                'radius': 0.4,
                'intensity': 9})

            bs.animate(self.light1, 'intensity',{0: self.light1.intensity, self.lightstimer: 0})

            def deleteLights():
                if self.light1.exists():
                    self.light1.delete()

            bs.gameTimer(self.lightstimer, deleteLights)

        def Lights2():
            self.light2 = bs.newNode('light', attrs={'position': (random.randint(0, 9)-4,4.5,random.randint(0, 9)-4),
                'color': (random.random(),random.random(),random.random()),
                'volumeIntensityScale': 1.0,
                'radius': 0.4,
                'intensity': 9})

            bs.animate(self.light2, 'intensity',{0: self.light2.intensity, self.lightstimer: 0})

            def deleteLights():
                    if self.light2.exists():
                        self.light2.delete()

            bs.gameTimer(self.lightstimer, deleteLights)
   
        def Lights3():
            self.light3 = bs.newNode('light', attrs={'position': (random.randint(0, 9)-4,4.5,random.randint(0, 9)-4),
                'color': (random.random(),random.random(),random.random()),
                'volumeIntensityScale': 1.0,
                'radius': 0.4,
                'intensity': 9})

            bs.animate(self.light3, 'intensity',{0: self.light3.intensity, self.lightstimer: 0})

            def deleteLights():
                if self.light3.exists():
                    self.light3.delete()

            bs.gameTimer(self.lightstimer, deleteLights)

        def LightsSlowshowTimer(on=True):
            if on:
                self.lightstimer = 1000
                self.lts1 = bs.gameTimer(1000, Lights1, repeat=True)

                def light2timer():
                    self.lts2 = bs.gameTimer(1000, Lights2, repeat=True)

                def light3timer():
                    self.lts3 = bs.gameTimer(1000, Lights3, repeat=True)

                    # start 2 light timer for look better
                self.lts2t1 = bs.gameTimer(300, light2timer)
                    # start 3 light timer for look better
                self.lts3t1 = bs.gameTimer(600, light3timer)
            else:
                self.lts1 = None
                self.lts2 = None
                self.lts3 = None
                self.lts2t1 = None
                self.lts3t1 = None
                if self.light1.exists():
                    self.light1.delete()

                if self.light2.exists():
                    self.light2.delete()

                if self.light3.exists():
                    self.light3.delete()

        def StrobeTimer(on=True):
            if on:
                self.light4 = bs.newNode('light', attrs={
                    'position': (0, 4.5, 0),
                    'color': (1, 1, 2),
                    'volumeIntensityScale': 1.0,
                    'radius': 10,
                    'intensity': 0.3})

                def switcher():
                    try:
                        self.light4.intensity = 0.3
                    except StandardError:
                        pass

                    def off():
                        try:
                            self.light4.intensity = 0
                        except StandardError:
                            pass

                    bs.gameTimer(40, off)

                self.ltstrobe = bs.gameTimer(80, switcher, repeat=True)
            else:
                self.ltstrobe = None
                if self.light4.exists():
                    self.light4.delete()

        def LightsFastshowTimer(on=True):
            if on:
                self.lightstimer = 400
                self.lt1 = bs.gameTimer(469, Lights1, repeat=True)
                self.lt2 = bs.gameTimer(469, Lights2, repeat=True)
                self.lt3 = bs.gameTimer(469, Lights3, repeat=True)

            else:
                self.lt1 = None
                self.lt2 = None
                self.lt3 = None
                if self.light1.exists():
                    self.light1.delete()

                if self.light2.exists():
                    self.light2.delete()

                if self.light3.exists():
                    self.light3.delete()
 
        def fadeOut():
            bs.animateArray(
                bsGlobals, 'vignetteInner', 3,
                {0: g.vignetteInner, 7000: (0, 0, 0)})

            bs.animateArray(
                bsGlobals, 'vignetteOuter', 3,
                {0: g.vignetteOuter, 7000: (0, 0, 0)})

            bs.animateArray(
                bsGlobals, 'tint', 3,
                {0: g.tint, 7000: (0, 0, 0)})

            self.lt1 = None
            self.lt2 = None
            self.lt3 = None
            self.lts1 = None
            self.lts2 = None
            self.lts3 = None
            self.lts2t1 = None
            self.lts3t1 = None
            if self.light1.exists():
                self.light1.delete()

            if self.light2.exists():
                self.light2.delete()

            if self.light3.exists():
                self.light3.delete()

        def intro():
            LightsSlowshowTimer()  

        def drop():
            self.jumping = True
            LightsSlowshowTimer(on=False)
            LightsFastshowTimer()
            StrobeTimer()

            def jump():
                s = int(random.random() * len(self._spazArray))
                self._spazArray[s].onJumpPress()
                self._spazArray[s].onJumpRelease()
                if self.jumping and not s == 40:
                    bs.gameTimer(50, bs.Call(jump))

            jump()

        def middle():
            self.jumping = False
            LightsSlowshowTimer()
            LightsFastshowTimer(on=False)
            StrobeTimer(on=False)

        intro()
        bs.gameTimer(35460, drop)
        bs.gameTimer(78620, middle)
        bs.gameTimer(128560, drop)
        bs.gameTimer(170000, middle)
        bs.gameTimer(175000, fadeOut)

        t = bs.newNode('text', attrs={
            'text':'Mapa hecho por ROUSS RRMX <3',
            'scale':1.2,
            'maxWidth':800,
            'position':(0,200),
            'shadow':0.5,
            'flatness':0.5,
            'hAlign':'center',
            'vAttach':'bottom'})
        c = bs.newNode('combine', owner=t, attrs={
            'size':4,
            'input0':0.3,
            'input1':0.9,
            'input2':0.0})
        bsUtils.animate(c, 'input3', {3000:0, 4000:1, 9000:1, 10000:0})
        c.connectAttr('output', t, 'color')
        bs.gameTimer(10000, t.delete) 

registerMap(Party)