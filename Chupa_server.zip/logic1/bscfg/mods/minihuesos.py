from bsSpaz import Appearance


t = Appearance("minihuesos")
#texture 1
t.colorTexture = "bonesColor"
t.colorMaskTexture = "bonesColorMask"
#nose jaja 
t.defaultColor = (0.5,0.2,0.2)
#t.defaultHighlight = (0.2,0.8,0.8)
#texture 2
t.iconTexture = "bonesIcon"
t.iconMaskTexture = "bonesIconColorMask"
#Cuerpo
t.headModel =     "bunnyPelvis"
t.torsoModel =    "bonesHead"
t.pelvisModel =   "bunnyPelvis"
t.upperArmModel = "bunnyPelvis"
t.foreArmModel =  "aliForeArm"
t.handModel =     "aliHand"
t.upperLegModel = "bonesUpperLeg"
t.lowerLegModel = "bonesUpperLeg"
t.toesModel =     "neoSpazToes"
#Sonidos
t.attackSounds = ['bones3']
t.jumpSounds = ['penguin1']
t.impactSounds = ["bonesDeath"]
t.deathSounds=['achievement']
t.pickupSounds = ['ooh']
t.fallSounds=["bonesFall"]

t.style = 'bones'  
#crado por jhoel