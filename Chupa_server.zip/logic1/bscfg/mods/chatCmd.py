# -*- coding: utf-8 -*-
import json
import bs
import bsInternal
import bsPowerup
import bsUtils
import random
import some
import threading
import handle
import DB_Manager as db
import kicker
import re
import datetime
import bsSpaz
from bsSpaz import *

costs = {
    'nv': 10,
    'heal': 20,
    'thaw': 5,
    'gp': 50,
    'reflections': 200,
    'end': 450,
    'playSound': 10,
    'ooh': 1,
    'box': 50,
    'spaz': 100
}
#costs = {'nv':10,'heal':20,'thaw':5,'sm':50,'gp':2,'reflections':20}

ownercommands = [
    'except', 'cm', 'take', 'unmute', 'mute', 'maxPlayers', 'ac', 'cameraMode',
    'admin', 'kill', 'kick', 'gm', 'floater', 'curse', 'freeze', 'shatter',
    'log', 'removetag', 'remove', 'pause', 'kick', 'fly', 'ban', 'hug',
    'freeze', 'quit', 'tint', 'icy', 'lm', 'permaban', 'warn', 'unwarn',
    'rt', 'laser', 'fireman', 'count', 'sm', 'nuke', 'speed', 'restringido'
    'addcoin', 'addtag', 'btag', 'restart', 'vip', 'public', '3d', '3dfly', 'console',
    'inv', 'unban', 'unperma', 'magicbox', 'rainbow', 'itx', 'cod', 'vip+', 'mayor'
]

coownercmd = [
    'except', 'cm', 'take', 'unmute', 'mute', 'ac', 'cameraMode',
    'kill', 'kick', 'gm', 'floater', 'curse', 'freeze', 'shatter',
    'end', 'log', 'removetag', 'remove', 'pause', 'fly', 'ban', 'hug',
    'freeze', 'quit', 'box', 'tint', 'icy', 'lm', 'warn', 'unwarn',
    'rt', 'laser', 'fireman', 'count', 'sm', 'nuke', 'speed', 'reflections',
    'playSound', 'addcoin', 'addtag', 'btag', 'restart', 'vip', 'spaz', '3d',
    '3dfly', 'gp', 'thaw', 'heal', 'nv', 'inv', 'ooh', 'magicbox', 'rainbow', 'clan', 'cod'
]

admincmd = [
    'cm', 'ac', 'cameraMode', 'kill',
'kick', 'gm', 'floater', 'curse', 'freeze',
    'end', 'remove', 'pause', 'fly', 'hug', 'shatter',
    'freeze', 'quit', 'box', 'tint', 'icy', 'lm', '3dfly', '3d',
    'rt', 'laser', 'fireman', 'count', 'reflections', 'sm', 'nuke', 'speed',
    'playSound', 'restart', 'spaz', 'gp', 'thaw', 'heal', 'nv', 'inv', 'ooh',
    'magicbox', 'rainbow'
]

vipcmd = [
 'box', 'reflections', 'sm', 'count', 'icy', 'end', 'ac', 'magicbox',
 'cameraMode', 'fireman', 'rt', 'cc', 'cn', 'ooh', 'nv', 'heal',
  'thaw', 'sm', 'freeze', 'hug', 'playSound', 'spaz', 'gp', 'fly', 'cm',
  'tint', 'inv', 'magicbox', 'rainbow'
]

clancmd = [
    'end', 'gp'
]

codcmd = [
    'end', 'gp'
]

vipacmd = [
 'box', 'reflections', 'sm', 'count', 'icy', 'end', 'ac', 'magicbox',
 'cameraMode', 'fireman', 'rt', 'cc', 'cn', 'ooh', 'nv', 'heal',
  'thaw', 'sm', 'freeze', 'hug', 'playSound', 'spaz', 'gp', 'fly', 'cm',
  'tint', 'inv', 'magicbox', 'rainbow', 'floater', 'gm'
]

mayorcmd = [
    'cm', 'ac', 'cameraMode', 'kill',
'kick', 'gm', 'floater', 'curse', 'freeze',
    'end', 'remove', 'pause', 'fly', 'hug', 'shatter',
    'freeze', 'quit', 'box', 'tint', 'icy', 'lm', '3dfly', '3d',
    'rt', 'laser', 'fireman', 'count', 'reflections', 'sm', 'nuke', 'speed',
    'playSound', 'restart', 'spaz', 'gp', 'thaw', 'heal', 'nv', 'inv', 'ooh',
    'magicbox', 'rainbow'
]

def find_players_and_bots():
    import inspect
    result=[]
    for i in bsInternal.getNodes(): 
        if hasattr(i, "getNodeType") and str(i.getNodeType()) == "spaz": 
            i = i.getDelegate()
            if isinstance(i, bsSpaz.PlayerSpaz) or (inspect.isclass(i.__class__) and issubclass(i.__class__, bsSpaz.SpazBot)): result.append(i)
    return result


def getActorNode(clientid):
    for i in bsInternal._getForegroundHostActivity().players:
        if int(clientid) == int(i.getInputDevice().getClientID()):
            return i.actor
            break
    else:
        return None


class chatOptions(object):
    def __init__(self):
        self.all = True  # just in case
        self.tint = (0.9, 0.9, 0.9)  # needs for /nv

    def checkDevice(self, clientID, msg):
        for i in bsInternal._getForegroundHostActivity().players:
            if i.getInputDevice().getClientID() == clientID:
                player = i
                break
        else:
            return None
        m = msg.split(' ')[0].replace('/', '')
        n = player.get_account_id()
        if db.getOwner(n):
            bs.screenMessage(u'\ue00cCOMANDO ACEPTADO MI REY\ue00c', clients=[clientID], transient=True)
            return True
        if db.getCoOwner(n) and m in coownercmd:
            bs.screenMessage(u'\ue00cCOMANDO ACEPTADO MI PRINCIPE\ue00c', clients=[clientID], transient=True)
            return True
        if db.getAdmin(n) and m in admincmd:
            bs.screenMessage(u'\ue00cCOMANDO ACEPTADO MR.MODERADOR\ue00c', clients=[clientID], transient=True)
            return True
        if db.getVip(n) and m in vipcmd:
            bs.screenMessage(u'\ue00cCOMANDO DEL VIP ACEPTADO\ue00c', clients=[clientID], transient=True)
            return True
        if db.getClan(n) and m in clancmd:
            bs.screenMessage(u'\ue00cCOMANDO DEL CLAN ITX ACEPTADO\ue00c', clients=[clientID], transient=True)
            return True
        if db.getCod(n) and m in codcmd:
            bs.screenMessage(u'\ue00cCOMANDO DEL CLAN COD ACEPTADO\ue00c', clients=[clientID], transient=True)
            return True
        if db.getVipa(n) and m in vipacmd:
            bs.screenMessage(u'\ue00cCOMANDO DEL VIP+ ACEPTADO\ue00c', clients=[clientID], transient=True)
            return True
        if db.getMayor(n) and m in mayorcmd:
            bs.screenMessage(u'\ue00cCOMANDO ACEPTADO MI SARGENTO\ue00c', clients=[clientID], transient=True)
            return True

    def Vip(self, nick):
        i = handle.getPlayerFromNick(nick)
        if i is None:
            bs.screenMessage('No esta el jugador')
            return
        n = i.get_account_id()
        print i.getName(True,False)
        try:
            db.makeVip(n,i.getName(True,False))
        except Exception, e: print e
        bs.screenMessage(u'{}\n ahora es VIP!'.format(
            i.getName(True)),
            color=(0.5,0.5,2.0))

    def tran(self, clientID, cost):
        cost = int(cost)
        for i in bsInternal._getForegroundHostActivity().players:
            if i.getInputDevice().getClientID() == clientID:
                n1 = i.get_account_id()
                clid = i.getInputDevice().getClientID()

        stats = db.getData(n1)

        coins = stats['p']
        if coins >= cost:
            coins -= cost
            stats['p'] = coins
            msgg = (u"Este costo de comando " + str(cost) +
                    u" \ue01f. El jugador ahora es " + str(coins) + u' \ue01f')
            bs.screenMessage(msgg, clients=[clid], transient=True)
            db.saveData(n1, stats)
            return True
        else:
            msgg = 'El comando cuesta: ' + \
                str(cost)+u'\ue01f. Usted tiene: '+str(coins)+u'\ue01f'
            bs.screenMessage(msgg, clients=[clid], transient=True)
            db.saveData(n1, stats)
            return False
            
    def coowner(self, nick):
        i = handle.getPlayerFromNick(nick)
        if i is None:
            bs.screenMessage('Error al encontrar al jugador')
            return
        n = i.get_account_id()
        print i.getName(True,False)
        try:
            db.makeCoOwner(n,i.getName(True,False))
        except Exception, e: print e
        bs.screenMessage(u'{}\n Ahora es Co-Owner!!'.format(
            i.getName(True)),
            color=(0.5,0.5,2.0))

    def admin(self, nick):
        i = handle.getPlayerFromNick(nick)
        if i is None:
            bs.screenMessage('Error al encontrar al jugador')
            return
        n = i.get_account_id()
        print i.getName(True,False)
        try:
            db.makeAdmin(n,i.getName(True,False))
        except Exception, e: print e
        bs.screenMessage(u'{}\n Ahora es admin!!'.format(
            i.getName(True)),
            color=(0.5,0.5,2.0))
            
    def clan(self, nick):
        i = handle.getPlayerFromNick(nick)
        if i is None:
            bs.screenMessage('Error al encontrar al jugador')
            return
        n = i.get_account_id()
        print i.getName(True,False)
        try:
            db.makeClan(n,i.getName(True,False))
        except Exception, e: print e
        bs.screenMessage(u'{} Ya es clan ITX'.format(
            i.getName(True)),
            color=(0.5,0.5,2.0))
            
    def cod(self, nick):
        i = handle.getPlayerFromNick(nick)
        if i is None:
            bs.screenMessage('Error al encontrar al jugador')
            return
        n = i.get_account_id()
        print i.getName(True,False)
        try:
            db.makeCod(n,i.getName(True,False))
        except Exception, e: print e
        bs.screenMessage(u'{} Ya es clan COD'.format(
            i.getName(True)),
            color=(0.5,0.5,2.0))
            
    def vipa(self, nick):
        i = handle.getPlayerFromNick(nick)
        if i is None:
            bs.screenMessage('Error al encontrar al jugador')
            return
        n = i.get_account_id()
        print i.getName(True,False)
        try:
            db.makeVipa(n,i.getName(True,False))
        except Exception, e: print e
        bs.screenMessage(u'{} Ahora ya es VIP+'.format(
            i.getName(True)),
            color=(0.5,0.5,2.0))
            
    def mayor(self, nick):
        i = handle.getPlayerFromNick(nick)
        if i is None:
            bs.screenMessage('Error al encontrar al jugador')
            return
        n = i.get_account_id()
        print i.getName(True,False)
        try:
            db.makeMayor(n,i.getName(True,False))
        except Exception, e: print e
        bs.screenMessage(u'{} Ahora ya es MAYOR'.format(
            i.getName(True)),
            color=(0.5,0.5,2.0))
            
    def deleteClan(self, nick):
        i = handle.getPlayerFromNick(nick)
        if i is None:
            bs.screenMessage('Error al encontrar al jugador')
            return
        n = i.get_account_id()
        print i.getName(True,False)
        try:
            db.deleteClan(n,i.getName(True,False))
        except Exception, e: print e
        bs.screenMessage('ITX removido\nExitosamente!',
            color=(1, 0.5, 0.5))
            
    def deleteCod(self, nick):
        i = handle.getPlayerFromNick(nick)
        if i is None:
            bs.screenMessage('Error al encontrar al jugador')
            return
        n = i.get_account_id()
        print i.getName(True,False)
        try:
            db.deleteCod(n,i.getName(True,False))
        except Exception, e: print e
        bs.screenMessage('COD removido\nExitosamente!',
            color=(1, 0.5, 0.5))

    def deletedmin(self, nick):
        i = handle.getPlayerFromNick(nick)
        if i is None:
            bs.screenMessage('Error al encontrar al jugador')
            return
        n = i.get_account_id()
        print i.getName(True,False)
        try:
            db.deleteAdmin(n,i.getName(True,False))
        except Exception, e: print e
        bs.screenMessage('Admin removido\nExitosamente!',
            color=(1, 0.5, 0.5))
    def deletecoowner(self, nick):
        i = handle.getPlayerFromNick(nick)
        if i is None:
            bs.screenMessage('Error al encontrar al jugador')
            return
        n = i.get_account_id()
        print i.getName(True,False)
        try:
            db.deleteCoOwner(n,i.getName(True,False))
        except Exception, e: print e
        bs.screenMessage('Co-Owner Removido\nExitosamente!',
            color=(1, 0.5, 0.5))
    def deletevip(self, nick):
        i = handle.getPlayerFromNick(nick)
        if i is None:
            bs.screenMessage('Error Al encontrar al jugador')
            return
        n = i.get_account_id()
        print i.getName(True,False)
        try:
            db.deleteVip(n,i.getName(True,False))
        except Exception, e: print e
        bs.screenMessage('Vip Removido\nExitosamente!',
            color=(1, 0.5, 0.5))
    def deletevipa(self, nick):
        i = handle.getPlayerFromNick(nick)
        if i is None:
            bs.screenMessage('Error Al encontrar al jugador')
            return
        n = i.get_account_id()
        print i.getName(True,False)
        try:
            db.deletevipa(n,i.getName(True,False))
        except Exception, e: print e
        bs.screenMessage('VIP+ Removido\nExitosamente!',
            color=(1, 0.5, 0.5))
    def deletemayor(self, nick):
        i = handle.getPlayerFromNick(nick)
        if i is None:
            bs.screenMessage('Error Al encontrar al jugador')
            return
        n = i.get_account_id()
        print i.getName(True,False)
        try:
            db.deletemayor(n,i.getName(True,False))
        except Exception, e: print e
        bs.screenMessage('Mayor Removido\nExitosamente!',
            color=(1, 0.5, 0.5))
  
    def msgText(self, t):
        time = 3
        tx = bs.newNode('text', attrs={
            'text': str(t),
            'position':(0,5,0),
            'inWorld': True,
            'scale': 0.02,
            'hAlign': 'center',
            'color': (random.random(),random.random(),random.random())
        })
        bs.gameTimer(time*1000, tx.delete)
        bs.animate(t, 'opacity', {0:1.0, time*1000:0})

    def textFromPlayer(self, i, t):
        if i.actor is None or not i.actor.node.exists():
            return
        time = 3
        m = bs.newNode('math', owner=i.actor.node, attrs={'input1': (0, 1.10, 0), 'operation':'add'})
        i.actor.node.connectAttr('position', m, 'input2')
        t = bs.newNode('text', attrs={
            'text': str(t),
            'inWorld': True,
            'hAlign': 'center',
            'shadow':2.0,
            'flatness':2.0,
            'color': (2, 2, 2)
        })
        m.connectAttr('output', t, 'position')
        bs.gameTimer(time*1000, t.delete)
        bs.animate(t, 'opacity', {0:1.0, time*1000:0})
        bs.animate(t, 'scale', {0:0, 500: 0.01})


            
    def permaban(self, nick):
        try:
            p = handle.getPlayerFromNick(nick)
            n = p.get_account_id()
            if n is not None:
                db.permaUser(n)
                ac_names = handle.getAccountNamesFromAccountID(n)
                if not ac_names in some.permabanned:
                    some.permabanned.extend(ac_names)    
                bs.screenMessage(
                    u'{} ha sido baneado!'.format(p.getName().encode('utf-8')),
                    color=(1,0,0))
                return
            else:
                for i in bsInternal._getGameRoster():
                    #print i
                    try:
                        if bs.utf8(i['displayString']).lower().find(
                                nick.encode('utf-8').lower()) != -1 or str(
                                    i['clientID']) == nick:
                            n = handle.getAccountIDFromAccountName(
                                i['displayString'].decode('utf-8').encode(
                                    'unicode_escape'))
                            n2 = handle.getAccountNamesFromAccountID(n)
                            db.permaUser(n)
                            bs.screenMessage(
                                u'{} ha sido baneado'.format(n2),
                                color=(1,0,0))
                            if not n2 in some.permabanned:
                                some.permabanned.extend(n2)
                            return
                    except Exception as e:
                        print e
        except Exception as e:
            bs.printException()

    def counter(self, time):
        bs.screenMessage(
            str(time) + ' segundos..')

        for i in range(time + 2):
            self._count = bs.gameTimer(((time + 2) - i)*1000,
                                   bs.Call(self.counter, i-1))

    def dickTula(self, nick):
        i = nick
        if i is None:
            bs.screenMessage('Error al encontrar al jugador')
            return
        size = random.randint(1, 1000)
        bsInternal._chatMessage(u'A {} le mide su turca {}cm'.format(
          i.getName(True,True), size))


    def PorcentajeDeFacha(self, nick):
        i = nick
        if i is None:
            bs.screenMessage('Error al encontrar al jugador')
            return
        porcentaje = random.randint(1, 100)
        bsInternal._chatMessage(u'{} Tiene un nivel de crack del {}%'.format(
            i.getName(True,True), porcentaje))

    def fireMan(self, i):
        if i.actor is None or not i.actor.node.exists():
            return
        bs.emitBGDynamics(
            position=tuple([i.actor.node.position[p]+random.uniform(-0.3, 0.3) for p in range(3)]),
            velocity=(0,0,0),
            count=10,
            scale=0.985 + random.uniform(-0.2,0.2),
            spread=0.05,
            chunkType='sweat')
        self._fire = bs.Timer(10, bs.WeakCall(self.fireMan, i), repeat=True)

    def ban(self, nick, secs, reason):
        try:
            p = handle.getPlayerFromNick(nick)
            n = p.get_account_id()
            if n is not None:
                db.banUser(n, secs, reason)
                ac_names = handle.getAccountNamesFromAccountID(n)
                some.banned.extend(ac_names)
                for i in ac_names:
                    with bs.Context('UI'):
                        bs.realTimer(secs * 1000,
                                     bs.Call(some.banned.remove, i))
                bs.screenMessage(
                    u'{} ha sido baneado temporal | Razon: {} | Vence en: {}'.format(
                        p.getName(), reason,
                        (datetime.datetime.now() + datetime.timedelta(
                            seconds=secs)).strftime('%d/%m/%Y, %H:%M:%S')))
                return
            else:
                for i in bsInternal._getGameRoster():
                    #print i
                    try:
                        if bs.utf8(i['displayString']).lower().find(
                                nick.encode('utf-8').lower()) != -1 or str(
                                    i['clientID']) == nick:
                            n = handle.getAccountIDFromAccountName(
                                i['displayString'].decode('utf-8').encode(
                                    'unicode_escape'))
                            n2 = handle.getAccountNamesFromAccountID(n)
                            db.banUser(n, secs, reason)
                            bs.screenMessage(
                                u'{} ha sido baneado temporal | Razon: {} | Vence en: {}'
                                .format(n, reason,
                                        (datetime.datetime.now() +
                                         datetime.timedelta(seconds=secs)
                                         ).strftime('%d/%m/%Y, %H:%M:%S')))
                            some.banned.extend(n2)
                            for i in n2:
                                with bs.Context('UI'):
                                    bs.realTimer(
                                        secs * 1000,
                                        bs.Call(some.banned.remove, i))
                            return
                    except Exception as e:
                        print e
            some.permabanned = open(some.banfile).read().split('\n')
        except Exception as e:
            bs.printException()

    def kickByNick(self, nick, reason='El admin uso el comando de kick'):
        kicker.kick(nick, reason)

    def opt(self, clientID, msg):
        try:
            activity = bsInternal._getForegroundHostActivity()
            with bs.Context(activity):
                checkdev = self.checkDevice(clientID, msg)
                m = msg.split(' ')[0].replace('/', '/').replace('/', '')
                if m in ownercommands and checkdev != True:
                    bs.screenMessage("No tienes acceso a este comando.",
                                     transient=True,
                                     clients=[clientID])
                    return
                else:
                    for i in bsInternal._getForegroundHostActivity().players:
                        if i.getInputDevice().getClientID() == clientID:
                            n = i.get_account_id()
                            player = i
                            break
                    else:
                        return

                    if m in costs and checkdev != True:
                        cost = costs[m]
                        if self.tran(clientID, cost) == False:
                            return
                    if not 'player' in locals():
                        return
                    if player is None:
                        return
                    m = msg.split(' ')[0].replace('/', '/')  # command
                    a = msg.split(' ')[1:]  # arguments
                    if m == '/ban':
                        if len(a) < 3:
                            bs.screenMessage(
                                "Uso: /ban <nombre/id/id del cliente> <tiempo[1m,5h,1d,etc.]> <razon>"
                            )
                        else:
                            seconds_per_unit = {
                                "s": 1,
                                "m": 60,
                                "h": 3600,
                                "d": 86400,
                                "w": 604800
                            }

                            def cts(s):
                                return int(s[:-1]) * seconds_per_unit[s[-1]]

                            self.ban(a[0], cts(a[1].lower()),
                                     (' '.join(a[2:])))

                    elif m == '/cn':
                        if a == []:
                            bs.screenMessage(
                                'Uso: /cn <id del cliente> para cambiar los nombres alos jugadores')
                        else:
                            spaz = getActorNode(int(a[0])).node
                            spaz.name = ' '.join(a[1:])
                    elif m == '/laser':
                        if a == []:
                            for i in range(len(activity.players)):
                                if activity.players[i].getInputDevice(
                                ).getClientID() == clientID:
                                    bsInternal._getForegroundHostActivity(
                                    ).players[i].actor.node.handleMessage(
                                        bs.PowerupMessage(
                                            powerupType='trailblazer'))
                    
                    elif m == '/console':
                        msg = ' ' .join(a).encode('utf-8')
                        bsInternal._chatMessage(msg)

                    elif m == '/whitelist':
                        if a[0] == 'off':
                            some.enableWithelist = False
                            bs.screenMessage('Lista blanca Activada')
                        else:
                            bs.screenMessage('Lista blanca desactivada')
                            some.enableWithelist = True

                    elif m == '/report':
                        if len(a) < 2:
                            bs.screenMessage(
                                'Escribe la razon del Reporte!\nUso: /reporte <id del cliente> <razon>')
                        else:
                            for i in bsInternal._getForegroundHostActivity().players:
                                if int(i.getInputDevice().getClientID()) == int(a[0]):
                                    to = i.getName()
                                    break
                            else:
                                return
                            reason = ' '.join(a[1:])
                            open(some.reportfile, 
                                 'a+').write('By: ' + player.getName() + ' | To: '
                                             + to + ' | Reason: ' + reason + '\n')
                            bs.screenMessage(
                                'Su reporte ha sido Enviado!', color=(0, 1, 0), clients=[clientID], transient=True)
                    elif m == '/3d':
                        def fly(actor=None):
                            def work(node=None):
                                if node is not None and node.exists():
                                    pos = node.position
                                    node.handleMessage("impulse",pos[0],pos[1]+.5,pos[2],0,5,0,3,10,0,0, 0,5,0)
                            if actor is not None and actor.exists():
                                if not hasattr(actor, '_fly') or (hasattr(actor, '_fly') and actor._fly is None):
                                    actor._fly = bs.Timer(58, bs.Call(work, actor.node), repeat=True)
                                    work(node=actor.node)
                                else: actor._fly = None
                        if a[0] == 'all':
                            for i in find_players_and_bots(): fly(i)
                        else:
                            if int(a[0]) < len(activity.players):
                                fly(activity.players[int(a[0])].actor)

                    elif m == '/3dfly':
                        if a == []:
                            def onJumpPress():
                                if not player.actor.node.exists() or player.actor.node.knockout > 0.0:
                                    return
                                player.actor.node.handleMessage(
                                    "impulse", player.actor.node.position[0], player.actor.node.position[1], player.actor.node.position[2],
                                    player.actor.node.moveLeftRight * 10, player.actor.node.position[1] + 32, player.actor.node.moveUpDown * -10,
                                    5, 5, 0, 0,
                                    player.actor.node.moveLeftRight * 10, player.actor.node.position[1] + 32, player.actor.node.moveUpDown * -10)
                            player.assignInputCall('jumpPress', onJumpPress)
                        else:
                            def onJumpPresss():
                                p = bs.getSession().players[int(a[0])].actor
                                if not p.node.exists() or p.node.knockout > 0.0:
                                    return
                                p.node.handleMessage(
                                    "impulse", p.node.position[0], p.node.position[1], p.node.position[2],
                                    p.node.moveLeftRight * 10, p.node.position[1] + 32, p.node.moveUpDown * -10,
                                    5, 5, 0, 0,
                                    p.node.moveLeftRight * 10, p.node.position[1] + 32, p.node.moveUpDown * -10)
                            bs.getSession().players[int(a[0])].assignInputCall('jumpPress', onJumpPresss)

                    elif m == '/public':
                        if a == []:
                            bsInternal._chatMessage('Uso: /public 0 o 1')
                        else:
                            if a[0] == '0':
                                try:
                                    bsInternal._setPublicPartyEnabled(False)
                                    bs.screenMessage('Fiesta privada.', color=(1, 1, 0))
                                except:
                                    bs.screenMessage(bs.Lstr(resource='errorText').evaluate(), color=(1, 0, 0))  
                            elif a[0] == '1':
                                try:
                                    bsInternal._setPublicPartyEnabled(True)
                                    bs.screenMessage('Fiesta publica.', color=(1, 1, 0))
                                except:
                                    bs.screenMessage(bs.Lstr(resource='errorText').evaluate(), color=(1, 0, 0))

                    elif m == '/magicbox':
                        FlyBox(position=getActorNode(clientID).node.position).autoRetain()
                    elif m == '/unperma':
                        some.permabanned=[]
                    elif m == '/cc':
                        if a[0] > 3:
                            bs.screenMessage(
                                'Valor del color excedido!')
                            return
                        if a == []:
                            for i in range(len(activity.players)):
                                if activity.players[i].getInputDevice(
                                ).getClientID() == clientID:
                                    bsInternal._getForegroundHostActivity(
                                    ).players[i].actor.node.color = (float(a[0]), 
                                        float(a[1]), 
                                            float(a[2]))
                        else:
                            spaz = getActorNode(a[0]).node
                            spaz.color = (float(a[1]), float(a[2]), float(a[3]))
                    elif m == '/m':
                        try:
                            self.textFromPlayer(player, ' '.join(a[0:]))
                        except Exception as e:
                            bs.printException()
                            return
                    elif m == '/addcoin':
                        try:
                            bs.screenMessage('se ha betado este comando temporalmente.')
                            return
                            n = player.get_account_id()
                            if n is None:return
                            stats = db.getData(n)
                            if a[0]>1000:
                                bs.screenMessage('Esa cantidad es exagerada!')
                            else:
                                stats['p'] += int(a[0])
                                msg = (u"Ok, Admin Se Han Transferido " + str(amount) +
                                       u"\ue01f Ha su Cuenta!")
                                bs.screenMessage(msg, color=(0, 1, 0))
                                bs.playSound(bs.getSound('cashRegister'))
                                db.saveData(n, stats)
                        except Exception as e:
                            pass
                    elif m == '/speed':
                        try:
                            if a == []:
                                bsInternal._chatMessage(
                                    'usage: /speed all or number list')
                            else:
                                if a[0] == 'all':
                                    for i in activity.players:
                                        if i.actor is not None and i.actor.node.exists():
                                            i.actor.node.hockey = True
                                else:
                                    activity.players[int(a[0])].actor.node.hockey = True
                        except:
                           pass



                    elif m == '/rainbow':
                        if a[0] == 'all':
                            for i in bs.getSession().players:
                                if i.actor is not None and i.actor.node.exists():
                                    #i.actor.node.handleMessage('celebrate', int(a[1])*1000)
                                    bs.animateArray(i.actor.node, 'color', 3, {
                                        0: (2,0,2),
                                        250: (2,0,0),
                                        250*2: (2,2,0),
                                        250*3: (0,2,2),
                                        250*4: (2,0,2)}, loop=True)
                        else:
                            a = int(a[0])
                            #bs.getSession().players[a].actor.node.handleMessage('celebrate', int(a[1])*1000)
                            bs.animateArray(bs.getSession().players[a].actor.node, 'color', 3, {
                                0: (2,0,2),
                                250: (2,0,0),
                                250*2: (2,2,0),
                                250*3: (0,2,2),
                                250*4: (2,0,2)}, loop=True)
                    elif m == '/nuke':
                        if a == []:
                            bs.screenMessage(
                                'Uso: /nuke <segundos> Para especificar a que hora cae la bomba/nuke')
                        else:
                            try:
                                t = int(a[0])
                                position = (player.actor.node.position[0],
                                            player.actor.node.position[1]+4,
                                            player.actor.node.position[2])
                                import portalObjects
                                def _nuke():
                                    portalObjects.Nuke(position=position).autoRetain()
                                bs.gameTimer(t*3000, bs.Call(_nuke))
                                def count(time):
                                    bs.screenMessage(
                                        'Una nuke sera lanzada en\n'+str(time)+'s...',
                                        color=(1,0,0)
                                    )
                                for i in range(t+3):
                                    bs.gameTimer(((t+3)-i)*1000,
                                                 bs.Call(count,i-1))
                            except:
                                portalObjects.Nuke(position=position).autoRetain()

                    elif m == '/dance':
                        def dance(actor=None):
                            def work(node=None):
                                if node is not None and node.exists():
                                    pos = (node.position[0], node.position[1] + 0.5, node.position[2])
                                    node.handleMessage("impulse", pos[0], pos[1], pos[2], 0, -2, 0, 2000, 0, 1, 0, 0, -2, 0)
                            if actor is not None and actor.exists(): 
                                if not hasattr(actor, '_dance') or (hasattr(actor, '_dance') and actor._dance is None):
                                    actor._dance = bs.Timer(100, bs.Call(work, actor.node), repeat=True)
                                    work(node=actor.node)
                                else: actor._dance = None
                        if a[0] == 'all':
                            for i in find_players_and_bots(): dance(i)
                        else:
                            if int(a[0]) < len(activity.players):
                                dance(activity.players[int(a[0])].actor)
                    elif m == '/count':
                        if a == []:
                            bs.screenMessage(
                                'Uso: /count <segundos>')
                        else:
                            bs.screenMessage(
                                'Iniciando Cuenta Regresiva!')
                            t = int(a[0])
                            def count(time):
                                bs.screenMessage(
                                    str(time)+'s',
                                    color=(0.5, 1.0, 0.5)
                                )
                            for i in range(t+2):
                                bs.gameTimer(((t+2)-i)*1000,
                                             bs.Call(count,i-1))


                    elif m == '/fireman':
                        try:
                            self.fireMan(player)
                        except Exception as e:
                            pass
                    elif m == '/turca':
                        self.dickTula(player)
                    elif m == '/crack':
                        self.PorcentajeDeFacha(player)
                    elif m == '/pito':
                        try:
                            handle.pito(player, a[0])
                        except Exception as e:
                            print e.message
                    elif m == '/give' or m == '/donate':
                        if len(a) < 2:
                            bsInternal._chatMessage(
                                'uso: /give nombre_del_jugador , cantidad')
                        else:
                            try:
                                handle.give(player, a[0], a[1],
                                            ' '.join(a[2:]))
                                bs.playSound(bs.getSound('cashRegister'))
                            except Exception as e:
                                print e.message
                    elif m == '/take':
                        if len(a) < 2:
                            bsInternal._chatMessage(
                                'uso: /take nombre_del_jugador cantidad')
                        else:
                            try:
                                handle.take(player, a[0], a[1],
                                            ' '.join(a[2:]))
                            except Exception as e:
                                print e.message
                    elif m == '/reload':
                        import autoreload
                        autoreload.update()
                        bs.reloadMedia()
                    elif m == '/redeem':
                        import json
                        codes = json.load(open(some.codefile))
                        if a[0] in codes:
                            if codes[a[0]]['s'] is None:
                                stats = db.getData(player.get_account_id())
                                stats['p'] += int(codes[a[0]]['t'])
                                db.saveData(player.get_account_id(), stats)
                                bs.screenMessage(
                                    'Felicidades! Has reclamado el Regalo Exitosamente Te hemos dado {} tickets! Unete al discord para ver el codigo cuando el owner lo de:)'
                                    .format(codes[a[0]]['t']),
                                    color=(0.5, 1, 0.5))
                                codes[a[0]]['s'] = player.getName(True)
                                open(some.codefile,
                                     'a+').write(json.dumps(codes))
                            else:
                                bs.screenMessage(
                                    u'XD el codigo ha sido usado por {}. llegastes tarde otra vez :(. Unete al discord para ver el codigo cuando el owner lo de! :)'
                                    .format(codes[a[0]]['s']),
                                    color=(1, 0.5, 0.5))
                        else:
                            bs.screenMessage(
                                'Ese codigo no existe. si no esta no introduzcas nada, Tonto. Unete al discord para ver el codigo cuando el owner lo de:)',
                                color=(1, 0.5, 0.5))
                    elif m == '/except':
                        if len(a) >= 1:
                            if not ' '.join(a[0:]).lower() in some.trans:
                                some.trans.append((' '.join(a[0:])).lower())
                                open(some.transfile,
                                     'a').write(' '.join(a[0:]).lower() + '\n')
                                bs.screenMessage('Agregando exepcion')
                            else:
                                bs.screenMessage(
                                    'La exepcion esta presente')
                    elif m == '/floater':
                        playerlist = bsInternal._getForegroundHostActivity(
                        ).players
                        if not hasattr(bsInternal._getForegroundHostActivity(),
                                       'flo'):
                            import floater
                            bsInternal._getForegroundHostActivity().flo = floater.Floater(bsInternal._getForegroundHostActivity()._mapType())
                        floater = bsInternal._getForegroundHostActivity().flo
                        if floater.controlled:
                            bs.screenMessage(
                                'El floater esta siendo manejado o eres un payaso y te fuiste hasta al final para hacerlo desaparecer',
                                color=(1, 0, 0))
                            return
                        for i in playerlist:
                            if i.getInputDevice().getClientID() == clientID:
                                clientID = i.getInputDevice().getClientID()
                                bs.screenMessage(
                                    'Usted\'Gano el Control sobre El Floater!\nToca bomba para Tirar bombas El golpe para dejar de controlarlo!\nToca saltar para bajar y agarrar para subir\nSeras liberado automaticamente despues de un tiempo. !',
                                    clients=[clientID],
                                    transient=True,
                                    color=(0.5, 2, 1))

                                def dis(i, floater):
                                    i.actor.node.invincible = False
                                    i.resetInput()
                                    i.actor.connectControlsToPlayer()
                                    floater.dis()

                                # bs.gameTimer(15000,bs.Call(dis,i,floater))
                                ps = i.actor.node.position
                                i.actor.node.invincible = True
                                floater.node.position = (ps[0], ps[1] + 1.5,
                                                         ps[2])
                                i.actor.node.holdNode = bs.Node(None)
                                i.actor.node.holdNode = floater.node2
                                i.actor.disconnectControlsFromPlayer()
                                i.resetInput()
                                floater.sourcePlayer = i
                                floater.con()
                                i.assignInputCall('pickUpPress', floater.up)
                                i.assignInputCall('pickUpRelease', floater.upR)
                                i.assignInputCall('jumpPress', floater.down)
                                i.assignInputCall('jumpRelease', floater.downR)
                                i.assignInputCall('bombPress', floater.drop)
                                i.assignInputCall('punchPress',
                                                  bs.Call(dis, i, floater))
                                i.assignInputCall('upDown', floater.updown)
                                i.assignInputCall('leftRight',
                                                  floater.leftright)
                                i.actor.afk_checker = None

                    elif m == '/mute':
                        if a == []:
                            bsInternal._chatMessage('El Admin silencio el chat')

                            def unmute():
                                if some.chatMuted:
                                    some.chatMuted = False
                                    bs.screenMessage('Ahora no podran hablar silencio',
                                                     transient=True,
                                                     color=(0.5, 0.5, 1))

                            with bs.Context('UI'):
                                bs.realTimer(120000, unmute)
                            some.chatMuted = True
                        else:
                            kicker.kick(a[0],
                                        reason=' '.join(a[1:]),
                                        mute=True,
                                        warn=True)
                    elif m == '/unmute':
                        bsInternal._chatMessage('Admin Desilencio el Chat')
                        some.chatMuted = False
                        import ChatManager
                        ChatManager.mutedIDs = []
                    elif m == '/discord':
                        bsInternal._chatMessage('https://discord.com/invite/ZFDc7zn8sb')
                    elif m == '/log':
                        open(some.logfile,
                             'a+').write('\n' * 5 +
                                         str(bsInternal._getGameRoster()) +
                                         '\n' +
                                         str(bsInternal._getChatMessages()))
                    elif m == '/whois':
                        if a == []:
                            bs.screenMessage('No hay rango existente')
                        elif not a[0].isdigit():
                            bs.screenMessage('No es un rango valido')
                        else:
                            handle.me(db.getUserFromRank(int(a[0])))
                    elif m == '/ip':
                        import reboot
                        bsInternal._chatMessage('IP: {} | Puerto: {}'.format(
                            reboot.ip, reboot.port))
                    elif m == '/me' or m == '/stats' or m == '/rank' or m == '/myself' or m == '/ranks':
                        if a == []:
                            bs.pushCall(100,handle.me(player))
                        else:
                            bs.pushCall(100,handle.me(handle.getPlayerFromNick(a[0])))
                    elif m in ['/in', '/inventory', '/items']:
                        if a == []:
                            handle.inv(player)
                        else:
                            handle.inv(handle.getPlayerFromNick(a[0]))
                    elif m == '/shop':
                        bsInternal._chatMessage("Puedes comprar esas cosas:")
                        bsInternal._chatMessage(
                            "Uso /buy <nombre_de la_ventaja> <no_de_dias>")

                        bsInternal._chatMessage('==========COMANDOS=========')
                        for i, k in costs.items():
                            bsInternal._chatMessage(
                                u"Comando: /{} {} Costo: {} \ue01f".format(
                                    i, ' ' * (20 - len(i)), str(k)))

                        bsInternal._chatMessage('==========VENTAJAS=========')
                        for i, k in some.prices.items():
                            bsInternal._chatMessage(
                                u"Nombre: {} {} Detalles: {} {} Costo: {} \ue01f/Dia"
                                .format(i.capitalize(), (' ' * (20 - len(i))),
                                        k['d'], (' ' * (20 - len(i))),
                                        str(k['c'])))

                        bs.screenMessage('\n' * 1000)
                    elif m == '/removetag':
                        n = handle.getPlayerFromNick(a[0]).get_account_id()
                        stats = db.getData(n)
                        stats['t'] = ''
                        bs.screenMessage('Etiqueta Removida')
                        db.saveData(n, stats)
                    elif m == '/addtag':
                        n = handle.getPlayerFromNick(a[0]).get_account_id()
                        stats = db.getData(n)
                        tag = ' '.join(a[1:])
                        if stats['t'] == '' or stats['t'] != '':
                            if len(tag) > 20:
                                return
                            tag = bs.uni(tag).replace(
                                '/c', u'\ue043').replace(
                                    '/d', u'\ue048')
                            stats['t'] = tag
                            bs.screenMessage('Etiqueta agregada')
                            db.saveData(n, stats)
                    elif m == '/throw':
                        if a == []:
                            bs.screenMessage('No hay objeto especificado')
                        else:
                            item = a[0]
                            import json
                            for i in bsInternal._getForegroundHostActivity(
                            ).players:
                                if i.getInputDevice().getClientID(
                                ) == clientID:
                                    n = i.get_account_id()
                                    break
                            else:
                                return
                            if True:
                                try:
                                    stats = db.getData(n)
                                    if item in stats['i']:
                                        stats['i'].pop(item)
                                        bs.screenMessage('Cosa tirada a donde sea')
                                    db.saveData(n, stats)
                                except Exception as e:
                                    print e
                                    return
                    elif m == '/id':
                        i = player
                        if i is not None:
                            n = i.get_account_id()
                            n2 = i.getInputDevice().getClientID()
                            bsInternal._chatMessage(
                                'Toma tu PBID %s : %s' %
                                (i.getName(True), n))
                        else:
                            #bs.screenMessage("Join Game First")
                            return
                    elif m == '/convert':
                        if len(a) == 1:
                            handle.convert(player, a[0])
                        else:
                            bsInternal._chatMessage('Uso: /convert cantidad')
                    elif m == '/bet' or m == '/gamble':
                        if a == []:
                            bs.screenMessage(
                                'Nesecitas una cantidad para apostar. Idiota.',
                                color=(1, .5, .5))
                            bsInternal._chatMessage(
                                'Uso: /bet [cantidad/all/half]')
                        else:
                            handle.bet(player, a[0])
                    elif m == '/beg':
                        handle.beg(player)
                    elif m == '/daily':
                        try:
                            handle.daily(clientID)
                        except Exception as e:
                            print e
                    elif m == '/buy':
                        if a == []:
                            bsInternal._chatMessage(
                                'La cosa que mencionas no esta. Usa/shop para ver la lista.'
                            )
                        else:
                            a[0] = bs.utf8(a[0]).lower()
                            if a[0] in some.prices:
                                import json
                                for i in bsInternal._getForegroundHostActivity(
                                ).players:
                                    if i.getInputDevice().getClientID(
                                    ) == clientID:
                                        n = i.get_account_id()
                                        break
                                else:
                                    return
                                if True:
                                    try:
                                        stats = {}
                                        stats = db.getData(n)
                                    except Exception as e:
                                        print e, '/buy get error'
                                        return
                                if a[0] in stats['i'] and a[0] not in ['tag']:
                                    bs.screenMessage(
                                        'Ya tienes comprado la cosa!')
                                    return
                                if ('backflip' in stats['i'] and a[0] == 'backflip-protection') or 'backflip-protection' in stats['i'] and a[0] == 'backflip':
                                    bs.screenMessage(
                                        'usted no\tiene proteccion contra volteretas hacia atras y hacia atras !')
                                    return
                                if a[0] != 'tag':
                                    try:
                                        limitDay = int(a[1])
                                        a[1] = int(a[1])
                                    except:
                                        limitDay = 1
                                else:
                                    limitDay = 9999
                                try:
                                    if stats['p'] >= (some.prices[a[0]]['c'] *
                                                      limitDay):
                                        stats['p'] -= (some.prices[a[0]]['c'] *
                                                       limitDay)
                                        import datetime
                                        expire_time = long(
                                            (datetime.datetime.now() +
                                             datetime.timedelta(days=limitDay)
                                             ).strftime("%Y%m%d%H%M")
                                        )  # (str(7*(len(History)//3)),"%d")
                                        if a[0] == 'tag':
                                            tag = ' '.join(a[1:])
                                            if len(tag) > 20:
                                                return
                                            tag = bs.uni(tag).replace(
                                                '/c', u'\ue043').replace(
                                                    '/d', u'\ue048')
                                            if not any(i in re.sub(
                                                    '[^A-Za-z0-9]+', '',
                                                    tag.lower()) for i in [
                                                        'moderator', 'admin',
                                                        'owner'
                                                    ]) and not tag.startswith(
                                                        u'\ue048#'):
                                                stats['t'] = tag
                                            else:
                                                return
                                        stats['i'].update({a[0]: expire_time})
                                        bs.playSound(bs.getSound('ding'))
                                        bs.screenMessage(
                                            'Compra exitosa! Vence en: {} | Usa /throw {} para quitarlo'
                                            .format(
                                                (datetime.datetime.strptime(
                                                    str(expire_time),
                                                    "%Y%m%d%H%M").strftime(
                                                        "%d-%m-%Y %H:%M:%S")),
                                                a[0]))
                                        db.saveData(n, stats)
                                    else:
                                        bs.screenMessage(u'No tienes suficiente \ue01f')
                                except Exception as e:
                                    print e
                            else:
                                bs.screenMessage("Esa cosa que te refieres no existe!")
                    if m == '/unban':
                        some.banned = []
                    if m == '/kick':
                        if a == []:
                            bsInternal._chatMessage(
                                'Uso: /kick nombre o numero de la lista')
                        else:
                            reason = ' '.join(
                                a[1:]) if ' '.join(a[1:]) != '' else None
                            self.kickByNick(a[0], reason=reason)
                    if m == '/unwarn':
                        some.warn = {}
                        bs.screenMessage('todas las advertencias han sido restablecidas')
                    if m == '/warn':
                        if a == []:
                            bsInternal._chatMessage(
                                'Using: /warn nombre o el numero de la lista')
                        else:
                            reason = ' '.join(
                                a[1:]) if ' '.join(a[1:]) != '' else None
                            kicker.kick(a[0], reason=reason, warn=True)
                    elif m == '/list':
                        bsInternal._chatMessage(
                            "======== PARA /kick SOLO: ========")
                        for i in bsInternal._getGameRoster():
                            try:
                                bsInternal._chatMessage(
                                    i['players'][0]['nameFull'] +
                                    "     (/kick " + str(i['clientID']) + ")")
                            except:
                                bsInternal._chatMessage(i['displayString'] +
                                                        "     (/kick " +
                                                        str(i['clientID']) +
                                                        ")")
                        bsInternal._chatMessage(
                            "==================================")
                        bsInternal._chatMessage(
                            "======= Para otros comandos: =======")
                        for s in bsInternal._getForegroundHostSession(
                        ).players:
                            bsInternal._chatMessage(
                                s.getName() + "     " +
                                str(bsInternal._getForegroundHostSession().
                                    players.index(s)))
                        bs.screenMessage('\n' * 1000)
                    elif m == '/ooh':
                        bs.playSound(bs.getSound('ooh'), volume=2)
                    elif m == '/playSound':
                        bs.playSound(bs.getSound(str(a[0])), volume=2)
                            
                    elif m == '/quit' or m == '/restart':

                        if len(a) == 1:
                            t = int(a[0])
                            def count(time):
                                bs.screenMessage(
                                    'El servidor sera reiniciado\nEn {} Segundos'.format(
                                        str(time)), color=(1.0, 0.5, 0.5))
                                if time == -1:
                                    bs.quit()
                            for i in range(t+2):
                                bs.gameTimer(((t+2)-i)*1000,
                                             bs.Call(count,i-1))
                        else:
                            bs.quit()



                    elif m == '/nv':
                        if self.tint is None:
                            self.tint = bs.getSharedObject('globals').tint
                        bs.getSharedObject('globals').tint = (
                            0.5, 0.7,
                            1) if a == [] or not a[0] == u'off' else self.tint

                    elif m == '/restringido':
                        if a == []:
                            bs.screenMessage(
                                'Este comando ha sido quitado')
                        else:
                            if a[0] == 'add':
                                self.coowner(a[1])

                            elif a[0] == 'remove':
                                self.deletecoowner(a[1])

                    elif m == '/admin':
                        if a == []:
                            bs.screenMessage(
                                'uso: /admin add/remove <id del cliente>')
                        else:
                            if a[0] == 'add':
                                self.admin(a[1])

                            elif a[0] == 'remove':
                                self.deletedmin(a[1])
                    elif m == '/vip':
                        if a == []:
                            bs.screenMessage(
                                'uso: /vip add/remove <id del cliente>')
                        else:
                            if a[0] == 'add':
                                self.Vip(a[1])

                            elif a[0] == 'remove':
                                self.deletevip(a[1])
                                
                    elif m == '/itx':
                        if a == []:
                            bs.screenMessage(
                                'uso: /itx add/remove <id del cliente>')
                        else:
                            if a[0] == 'add':
                                self.clan(a[1])

                            elif a[0] == 'remove':
                                self.deleteClan(a[1])
                                
                    elif m == '/cod':
                        if a == []:
                            bs.screenMessage(
                                'uso: /cod add/remove <id del cliente>')
                        else:
                            if a[0] == 'add':
                                self.cod(a[1])

                            elif a[0] == 'remove':
                                self.deleteCod(a[1])

                    elif m == '/vip+':
                        if a == []:
                            bs.screenMessage(
                                'uso: /vip+ add/remove <id del cliente>')
                        else:
                            if a[0] == 'add':
                                self.vipa(a[1])

                            elif a[0] == 'remove':
                                self.deleteVipa(a[1])

                    elif m == '/mayor':
                        if a == []:
                            bs.screenMessage(
                                'uso: /major add/remove <id del cliente>')
                        else:
                            if a[0] == 'add':
                                self.mayor(a[1])

                            elif a[0] == 'remove':
                                self.deleteMayor(a[1])

                    elif m == '/permaban':
                        s = a[0]
                        self.permaban(s)
                    elif m == '/freeze':
                        if a == []:
                            bsInternal._chatMessage(
                                'Uso: /freeze all o el numero de la lista')
                        else:
                            if a[0] == 'all':
                                for i in bs.getSession().players:
                                    try:
                                        i.actor.node.handleMessage(
                                            bs.FreezeMessage())
                                    except:
                                        pass
                            else:
                                bs.getSession().players[int(
                                    a[0])].actor.node.handleMessage(
                                        bs.FreezeMessage())
                    elif m == '/thaw':
                        if a == []:
                            for i in range(len(activity.players)):
                                if activity.players[i].getInputDevice(
                                ).getClientID() == clientID:
                                    bsInternal._getForegroundHostActivity(
                                    ).players[i].actor.node.handleMessage(
                                        bs.ThawMessage())
                        else:
                            if a[0] == 'all':
                                for i in bs.getSession().players:
                                    try:
                                        i.actor.node.handleMessage(
                                            bs.ThawMessage())
                                    except:
                                        pass
                            else:
                                bs.getSession().players[int(
                                    a[0])].actor.node.handleMessage(
                                        bs.ThawMessage())
                    elif m == '/kill':
                        if a == []:
                            bsInternal._chatMessage(
                                'Uso: /kill all o el numero de la lista')
                        else:
                            if a[0] == 'all':
                                for i in bs.getSession().players:
                                    try:
                                        i.actor.node.handleMessage(
                                            bs.DieMessage())
                                    except:
                                        pass
                            else:
                                bs.getSession().players[int(
                                    a[0])].actor.node.handleMessage(
                                        bs.DieMessage())
                    elif m == '/curse':
                        if a == []:
                            bsInternal._chatMessage(
                                'Using: /curse all o el numero de la lista')
                        else:
                            if a[0] == 'all':
                                for i in bs.getSession().players:
                                    try:
                                        i.actor.curse()
                                    except:
                                        pass
                            else:
                                bs.getSession().players[int(
                                    a[0])].actor.curse()
                    elif m == '/inv':
                        if a == []:
                            bsInternal._chatMessage('Uso: /inv all o numero de la lista')
                        else:
                            try:
                                if a[0] == 'all':
                                    for i in bs.getSession().players:
                                        t = i.actor.node
                                        try:
                                           t.headModel =     None
                                           t.torsoModel =    None
                                           t.pelvisModel =   None
                                           t.upperArmModel = None
                                           t.foreArmModel =  None
                                           t.handModel =     None
                                           t.upperLegModel = None
                                           t.lowerLegModel = None
                                           t.toesModel =     None
                                           t.style = "cyborg"
                                        except:
                                           print 'error'
                                else:
                                    n = int(a[0])
                                    t = bs.getSession().players[n].actor.node
                                                                        
                                    t.headModel =     None
                                    t.torsoModel =    None
                                    t.pelvisModel =   None
                                    t.upperArmModel = None
                                    t.foreArmModel =  None
                                    t.handModel =     None
                                    t.upperLegModel = None
                                    t.lowerLegModel = None
                                    t.toesModel =     None
                                    t.style = "cyborg"
                            except:
                                bs.screenMessage('Error!',color = (1,0,0))

                    elif m == '/spaz':
                        try:
                            if a == []:
                                bsInternal._chatMessage('Fallo!! Uso: /spazall or /spaz numero de la lista')
                            else:
                                if a[0] == 'all':
                                    for i in bs.getSession().players:
                                        #a.append(a[0])
                                        t = i.actor.node
                                        try:
                                            if a[1] in ['ali','neoSpaz','wizard','cyborg','penguin','agent','pixie','bear','bunny', 'zoe']:
                                                t.colorTexture = bs.getTexture(a[1] + 'Color')
                                                t.colorMaskTexture = bs.getTexture(a[1] + 'ColorMask')
                                                t.headModel = bs.getModel(a[1] + 'Head')
                                                t.torsoModel = bs.getModel(a[1] + 'Torso')
                                                t.pelvisModel = bs.getModel(a[1] + 'Pelvis')
                                                t.upperArmModel = bs.getModel(a[1] + 'UpperArm')
                                                t.foreArmModel = bs.getModel(a[1] + 'ForeArm')
                                                t.handModel = bs.getModel(a[1] + 'Hand')
                                                t.upperLegModel = bs.getModel(a[1] + 'UpperLeg')
                                                t.lowerLegModel = bs.getModel(a[1] + 'LowerLeg')
                                                t.toesModel = bs.getModel(a[1] + 'Toes')
                                                t.style = 'female' if a[1] == 'zoe' else a[1]
                                                bs.screenMessage('All skin change!')
                                        except:
                                            print 'error'
                                else:
                                    try:
                                        if a[1] in ['ali','neoSpaz','wizard','cyborg','penguin','agent','pixie','bear','bunny', 'zoe']:
                                            n = int(a[0])
                                            t = bs.getSession().players[n].actor.node
                                            t.colorTexture = bs.getTexture(a[1] + 'Color')
                                            t.colorMaskTexture = bs.getTexture(a[1] + 'ColorMask')
                                            t.headModel = bs.getModel(a[1] + 'Head')
                                            t.torsoModel = bs.getModel(a[1] + 'Torso')
                                            t.pelvisModel = bs.getModel(a[1] + 'Pelvis')
                                            t.upperArmModel = bs.getModel(a[1] + 'UpperArm')
                                            t.foreArmModel = bs.getModel(a[1] + 'ForeArm')
                                            t.handModel = bs.getModel(a[1] + 'Hand')
                                            t.upperLegModel = bs.getModel(a[1] + 'UpperLeg')
                                            t.lowerLegModel = bs.getModel(a[1] + 'LowerLeg')
                                            t.toesModel = bs.getModel(a[1] + 'Toes')
                                            t.style = 'female' if a[1] == 'zoe' else a[1]
                                            bs.screenMessage('Player skin change!')
        
                                    except:
                                        bsInternal._chatMessage('Fallo!! Uso: /spazall or /spaz numero de la lista')

                        except:
                            bs.screenMessage('error', color=(1, 0, 0))
                    elif m == '/box':
                        if a == []:
                            bsInternal._chatMessage(
                                'Uso: /box all o numero de la lista')
                        else:
                            try:
                                if a[0] == 'all':
                                    for i in bs.getSession().players:
                                        try:
                                            i.actor.node.torsoModel = bs.getModel(
                                                "tnt")
                                        except:
                                            pass
                                    for i in bs.getSession().players:
                                        try:
                                            i.actor.node.colorMaskTexture = bs.getTexture(
                                                "tnt")
                                        except:
                                            pass
                                    for i in bs.getSession().players:
                                        try:
                                            i.actor.node.colorTexture = bs.getTexture(
                                                "tnt")
                                        except:
                                            pass
                                    for i in bs.getSession().players:
                                        try:
                                            i.actor.node.highlight = (1, 1, 1)
                                        except:
                                            pass
                                    for i in bs.getSession().players:
                                        try:
                                            i.actor.node.color = (1, 1, 1)
                                        except:
                                            pass
                                    for i in bs.getSession().players:
                                        try:
                                            i.actor.node.headModel = None
                                        except:
                                            pass
                                    for i in bs.getSession().players:
                                        try:
                                            i.actor.node.style = "cyborg"
                                        except:
                                            pass
                                else:
                                    n = int(a[0])
                                    bs.getSession().players[
                                        n].actor.node.torsoModel = bs.getModel(
                                            "tnt")
                                    bs.getSession().players[
                                        n].actor.node.colorMaskTexture = bs.getTexture(
                                            "tnt")
                                    bs.getSession().players[
                                        n].actor.node.colorTexture = bs.getTexture(
                                            "tnt")
                                    bs.getSession(
                                    ).players[n].actor.node.highlight = (1, 1,
                                                                         1)
                                    bs.getSession(
                                    ).players[n].actor.node.color = (1, 1, 1)
                                    bs.getSession(
                                    ).players[n].actor.node.headModel = None
                                    bs.getSession(
                                    ).players[n].actor.node.style = "cyborg"
                            except:
                                bs.screenMessage('Error!', color=(1, 0, 0))
                    elif m == '/remove':
                        if a == []:
                            bsInternal._chatMessage(
                                'Uso: /remove all o el numero de la lista')
                        else:
                            if a[0] == 'all':
                                for i in bs.getSession().players:
                                    try:
                                        i.removeFromGame()
                                    except:
                                        pass
                            else:
                                bs.getSession().players[int(
                                    a[0])].removeFromGame()
                    elif m == '/end':
                        try:
                            bsInternal._getForegroundHostActivity().endGame()
                            bs.screenMessage(
                                "Finalizando Partida\nEspere un minuto", color=(0.5, 0.5, 1))
                        except:
                            bs.screenMessage(
                                "Ya se Finalizo\nLa Partida", color=(1, 0.5, 0.5))
                    elif m == '/hug':
                        if a == []:
                            bsInternal._chatMessage(
                                'Uso: /hug all o el numero de la lista')
                        else:
                            try:
                                if a[0] == 'all':
                                    try:
                                        bsInternal._getForegroundHostActivity(
                                        ).players[
                                            0].actor.node.holdNode = bsInternal._getForegroundHostActivity(
                                            ).players[1].actor.node
                                    except:
                                        pass
                                    try:
                                        bsInternal._getForegroundHostActivity(
                                        ).players[
                                            1].actor.node.holdNode = bsInternal._getForegroundHostActivity(
                                            ).players[0].actor.node
                                    except:
                                        pass
                                    try:
                                        bsInternal._getForegroundHostActivity(
                                        ).players[
                                            3].actor.node.holdNode = bsInternal._getForegroundHostActivity(
                                            ).players[2].actor.node
                                    except:
                                        pass
                                    try:
                                        bsInternal._getForegroundHostActivity(
                                        ).players[
                                            4].actor.node.holdNode = bsInternal._getForegroundHostActivity(
                                            ).players[3].actor.node
                                    except:
                                        pass
                                    try:
                                        bsInternal._getForegroundHostActivity(
                                        ).players[
                                            5].actor.node.holdNode = bsInternal._getForegroundHostActivity(
                                            ).players[6].actor.node
                                    except:
                                        pass
                                    try:
                                        bsInternal._getForegroundHostActivity(
                                        ).players[
                                            6].actor.node.holdNode = bsInternal._getForegroundHostActivity(
                                            ).players[7].actor.node
                                    except:
                                        pass
                                else:
                                    bsInternal._getForegroundHostActivity(
                                    ).players[int(
                                        a[0]
                                    )].actor.node.holdNode = bsInternal._getForegroundHostActivity(
                                    ).players[int(a[1])].actor.node
                            except:
                                bs.screenMessage('Error!', color=(1, 0, 0))
                    elif m == '/gm':
                        if a == []:
                            for i in range(len(activity.players)):
                                if activity.players[i].getInputDevice(
                                ).getClientID() == clientID:
                                    activity.players[
                                        i].actor.node.hockey = activity.players[
                                            i].actor.node.hockey == False
                                    activity.players[
                                        i].actor.node.invincible = activity.players[
                                            i].actor.node.invincible == False
                                    activity.players[
                                        i].actor._punchPowerScale = 5 if activity.players[
                                            i].actor._punchPowerScale == 1.2 else 1.2
                        else:
                            activity.players[int(
                                a[0])].actor.node.hockey = activity.players[
                                    int(a[0])].actor.node.hockey == False
                            activity.players[int(
                                a[0]
                            )].actor.node.invincible = activity.players[int(
                                a[0])].actor.node.invincible == False
                            activity.players[int(
                                a[0]
                            )].actor._punchPowerScale = 5 if activity.players[
                                int(a[0]
                                    )].actor._punchPowerScale == 1.2 else 1.2
                    elif m == '/tint':
                        if a == []:
                            bsInternal._chatMessage('Uso: /tint R G B')
                            bsInternal._chatMessage('OR')
                            bsInternal._chatMessage(
                                'Uso: /tint r bright speed')
                        else:
                            if a[0] == 'r':
                                m = 1.3 if a[1] is None else float(a[1])
                                s = 1000 if a[2] is None else float(a[2])
                                bsUtils.animateArray(
                                    bs.getSharedObject('globals'), 'tint', 3, {
                                        0: (1 * m, 0, 0),
                                        s: (0, 1 * m, 0),
                                        s * 2: (0, 0, 1 * m),
                                        s * 3: (1 * m, 0, 0)
                                    }, True)
                            else:
                                try:
                                    if a[1] is not None:
                                        bs.getSharedObject('globals').tint = (
                                            float(a[0]), float(a[1]),
                                            float(a[2]))
                                    else:
                                        bs.screenMessage('Error!',
                                                         color=(1, 0, 0))
                                except:
                                    bs.screenMessage('Error!', color=(1, 0, 0))
                    elif m == '/pause':
                        bs.getSharedObject(
                            'globals').paused = bs.getSharedObject(
                                'globals').paused == False
                    elif m == '/sm':
                        bs.getSharedObject(
                            'globals').slowMotion = bs.getSharedObject(
                                'globals').slowMotion == False
                    # elif m == '/bunny':
                    #     if a == []:
                    #         bsInternal._chatMessage('Using: /bunny count owner(number of list)')
                    #     import BuddyBunny
                    #     for i in range(int(a[0])):
                    #         p=bs.getSession().players[int(a[1])]
                    #         if not 'bunnies' in p.gameData:
                    #             p.gameData['bunnies'] = BuddyBunny.BunnyBotSet(p)
                    #         p.gameData['bunnies'].doBunny()
                    elif m == '/cameraMode':
                        try:
                            if bs.getSharedObject(
                                    'globals').cameraMode == 'follow':
                                bs.getSharedObject(
                                    'globals').cameraMode = 'rotate'
                            else:
                                bs.getSharedObject(
                                    'globals').cameraMode = 'follow'
                        except:
                            pass
                    elif m == '/lm':
                        arr = []
                        for i in range(100):
                            try:
                                arr.append(bsInternal._getChatMessages()[-1 -
                                                                         i])
                            except:
                                pass
                        arr.reverse()
                        for i in arr:
                            if not 'Server67323: ' in i:
                                bsInternal._chatMessage(i)
                    elif m == '/gp':
                        if a == []:
                            bsInternal._chatMessage(
                                'que estas haciendo acosdor respeta. uso /gp id del jugador')
                        else:
                            s = bsInternal._getForegroundHostSession()
                            for i in s.players[int(a[0])].getInputDevice(
                            )._getPlayerProfiles():
                                try:
                                    bsInternal._chatMessage(i)
                                except:
                                    pass
                            bs.screenMessage('\n' * 1000)
                    elif m == '/joke':
                        threading.Thread(target=handle.joke,
                                         args=(player.getName(
                                             True, False), )).start()

                    elif m == '/icy':
                        bsInternal._getForegroundHostActivity().players[int(
                            a[0]
                        )].actor.node = bsInternal._getForegroundHostActivity(
                        ).players[int(a[1])].actor.node
                    elif m == '/fly':
                        if a == []:
                            bsInternal._chatMessage(
                                'Uso: /fly all o numero de la lista')
                        else:
                            if a[0] == 'all':
                                for i in bsInternal._getForegroundHostActivity(
                                ).players:
                                    i.actor.node.fly = True
                            else:
                                bsInternal._getForegroundHostActivity(
                                ).players[int(
                                    a[0]
                                )].actor.node.fly = bsInternal._getForegroundHostActivity(
                                ).players[int(a[0])].actor.node.fly == False
                    elif m == '/floorReflection':
                        bs.getSharedObject(
                            'globals').floorReflection = bs.getSharedObject(
                                'globals').floorReflection == False
                    elif m == '/next':
                        top = bs.Lstr(value='${A}  ${B}', subs=[('${A}', bs.Lstr(resource='nextGame').evaluate()), ('${B}',bsInternal._getForegroundHostSession().getNextGameDescription())])
                        bs.screenMessage(top, clients=[clientID], transient=True)
                    elif m == '/ac':
                        if a == []:
                            bsInternal._chatMessage('Usando: /ac R G B')
                            bsInternal._chatMessage('OR')
                            bsInternal._chatMessage(
                                'Uso: /ac r bright speed')
                        else:
                            if a[0] == 'r':
                                m = 1.3 if a[1] is None else float(a[1])
                                s = 1000 if a[2] is None else float(a[2])
                                bsUtils.animateArray(
                                    bs.getSharedObject('globals'),
                                    'ambientColor', 3, {
                                        0: (1 * m, 0, 0),
                                        s: (0, 1 * m, 0),
                                        s * 2: (0, 0, 1 * m),
                                        s * 3: (1 * m, 0, 0)
                                    }, True)
                            else:
                                try:
                                    if a[1] is not None:
                                        bs.getSharedObject(
                                            'globals').ambientColor = (float(
                                                a[0]), float(a[1]), float(
                                                    a[2]))
                                    else:
                                        bs.screenMessage('Error!',
                                                         color=(1, 0, 0))
                                except:
                                    bs.screenMessage('Error!', color=(1, 0, 0))
                    elif m == '/rt':
                        global times
                        if a == []:
                            choice = 1
                        else:
                            choice = int(a[0])
                        times = 1
                        defdict = {}

                        def fix():
                            for i, k in defdict.items():
                                try:
                                    i.colorTexture = k
                                except:
                                    pass

                        def asset():
                            global times
                            nodes = bs.getNodes()
                            times += 1
                            assets = []
                            models = []
                            assetnames = [
                                'achievementBoxer', 'achievementCrossHair',
                                'achievementDualWielding', 'achievementEmpty',
                                'achievementFlawlessVictory',
                                'achievementFootballShutout',
                                'achievementFootballVictory',
                                'achievementFreeLoader',
                                'achievementGotTheMoves',
                                'achievementInControl',
                                'achievementMedalLarge',
                                'achievementMedalMedium',
                                'achievementMedalSmall', 'achievementMine',
                                'achievementOffYouGo', 'achievementOnslaught',
                                'achievementOutline', 'achievementRunaround',
                                'achievementSharingIsCaring',
                                'achievementStayinAlive',
                                'achievementSuperPunch', 'achievementTNT',
                                'achievementTeamPlayer', 'achievementWall',
                                'achievementsIcon', 'actionButtons',
                                'actionHeroColor', 'actionHeroColorMask',
                                'actionHeroIcon', 'actionHeroIconColorMask',
                                'advancedIcon', 'agentColor', 'agentColorMask',
                                'agentIcon', 'agentIconColorMask',
                                'aliBSRemoteIOSQR', 'aliColor', 'aliColorMask',
                                'aliControllerQR', 'aliIcon',
                                'aliIconColorMask', 'aliSplash', 'alienColor',
                                'alienColorMask', 'alienIcon',
                                'alienIconColorMask', 'alwaysLandBGColor',
                                'alwaysLandLevelColor', 'alwaysLandPreview',
                                'analogStick', 'arrow', 'assassinColor',
                                'assassinColorMask', 'assassinIcon',
                                'assassinIconColorMask', 'audioIcon',
                                'backIcon', 'bar', 'bearColor',
                                'bearColorMask', 'bearIcon',
                                'bearIconColorMask', 'bg', 'bigG',
                                'bigGPreview', 'black', 'bombButton',
                                'bombColor', 'bombColorIce', 'bombStickyColor',
                                'bonesColor', 'bonesColorMask', 'bonesIcon',
                                'bonesIconColorMask', 'boxingGlovesColor',
                                'bridgitLevelColor', 'bridgitPreview',
                                'bunnyColor', 'bunnyColorMask', 'bunnyIcon',
                                'bunnyIconColorMask', 'buttonBomb',
                                'buttonJump', 'buttonPickUp', 'buttonPunch',
                                'buttonSquare', 'chTitleChar1', 'chTitleChar2',
                                'chTitleChar3', 'chTitleChar4', 'chTitleChar5',
                                'characterIconMask', 'chestIcon',
                                'chestIconEmpty', 'chestIconMulti',
                                'chestOpenIcon', 'circle', 'circleNoAlpha',
                                'circleOutline', 'circleOutlineNoAlpha',
                                'circleShadow', 'circleZigZag', 'coin',
                                'controllerIcon', 'courtyardLevelColor',
                                'courtyardPreview', 'cowboyColor',
                                'cowboyColorMask', 'cowboyIcon',
                                'cowboyIconColorMask', 'cragCastleLevelColor',
                                'cragCastlePreview', 'crossOut',
                                'crossOutMask', 'cursor', 'cuteSpaz',
                                'cyborgColor', 'cyborgColorMask', 'cyborgIcon',
                                'cyborgIconColorMask', 'doomShroomBGColor',
                                'doomShroomLevelColor', 'doomShroomPreview',
                                'downButton', 'egg1', 'egg2', 'egg3', 'egg4',
                                'eggTex1', 'eggTex2', 'eggTex3', 'empty',
                                'explosion', 'eyeColor', 'eyeColorTintMask',
                                'file', 'flagColor', 'flagPoleColor', 'folder',
                                'fontBig', 'fontExtras', 'fontExtras2',
                                'fontExtras3', 'fontExtras4', 'fontSmall0',
                                'fontSmall1', 'fontSmall2', 'fontSmall3',
                                'fontSmall4', 'fontSmall5', 'fontSmall6',
                                'fontSmall7', 'footballStadium',
                                'footballStadiumPreview', 'frameInset',
                                'frostyColor', 'frostyColorMask', 'frostyIcon',
                                'frostyIconColorMask', 'fuse',
                                'gameCenterIcon', 'gameCircleIcon',
                                'gladiatorColor', 'gladiatorColorMask',
                                'gladiatorIcon', 'gladiatorIconColorMask',
                                'glow', 'googlePlayAchievementsIcon',
                                'googlePlayGamesIcon',
                                'googlePlayLeaderboardsIcon', 'googlePlusIcon',
                                'googlePlusSignInButton', 'graphicsIcon',
                                'heart', 'hockeyStadium',
                                'hockeyStadiumPreview', 'iconOnslaught',
                                'iconRunaround', 'impactBombColor',
                                'impactBombColorLit', 'inventoryIcon',
                                'jackColor', 'jackColorMask', 'jackIcon',
                                'jackIconColorMask', 'jumpsuitColor',
                                'jumpsuitColorMask', 'jumpsuitIcon',
                                'jumpsuitIconColorMask', 'kronk',
                                'kronkColorMask', 'kronkIcon',
                                'kronkIconColorMask', 'lakeFrigid',
                                'lakeFrigidPreview', 'lakeFrigidReflections',
                                'landMine', 'landMineLit', 'leaderboardsIcon',
                                'leftButton', 'levelIcon', 'light',
                                'lightSharp', 'lightSoft', 'lock', 'logIcon',
                                'logo', 'logoEaster', 'mapPreviewMask',
                                'medalBronze', 'medalComplete', 'medalGold',
                                'medalSilver', 'melColor', 'melColorMask',
                                'melIcon', 'melIconColorMask', 'menuBG',
                                'menuButton', 'menuIcon', 'meter',
                                'monkeyFaceLevelColor', 'monkeyFacePreview',
                                'multiplayerExamples', 'natureBackgroundColor',
                                'neoSpazColor', 'neoSpazColorMask',
                                'neoSpazIcon', 'neoSpazIconColorMask',
                                'nextLevelIcon', 'ninjaColor',
                                'ninjaColorMask', 'ninjaIcon',
                                'ninjaIconColorMask', 'nub', 'null',
                                'oldLadyColor', 'oldLadyColorMask',
                                'oldLadyIcon', 'oldLadyIconColorMask',
                                'operaSingerColor', 'operaSingerColorMask',
                                'operaSingerIcon', 'operaSingerIconColorMask',
                                'ouyaAButton', 'ouyaIcon', 'ouyaOButton',
                                'ouyaUButton', 'ouyaYButton', 'penguinColor',
                                'penguinColorMask', 'penguinIcon',
                                'penguinIconColorMask', 'pixieColor',
                                'pixieColorMask', 'pixieIcon',
                                'pixieIconColorMask', 'playerLineup',
                                'powerupBomb', 'powerupCurse', 'powerupHealth',
                                'powerupIceBombs', 'powerupImpactBombs',
                                'powerupLandMines', 'powerupPunch',
                                'powerupShield', 'powerupSpeed',
                                'powerupStickyBombs', 'puckColor',
                                'rampageBGColor', 'rampageBGColor2',
                                'rampageLevelColor', 'rampagePreview',
                                'reflectionChar_+x', 'reflectionChar_+y',
                                'reflectionChar_+z', 'reflectionChar_-x',
                                'reflectionChar_-y', 'reflectionChar_-z',
                                'reflectionPowerup_+x', 'reflectionPowerup_+y',
                                'reflectionPowerup_+z', 'reflectionPowerup_-x',
                                'reflectionPowerup_-y', 'reflectionPowerup_-z',
                                'reflectionSharp_+x', 'reflectionSharp_+y',
                                'reflectionSharp_+z', 'reflectionSharp_-x',
                                'reflectionSharp_-y', 'reflectionSharp_-z',
                                'reflectionSharper_+x', 'reflectionSharper_+y',
                                'reflectionSharper_+z', 'reflectionSharper_-x',
                                'reflectionSharper_-y', 'reflectionSharper_-z',
                                'reflectionSharpest_+x',
                                'reflectionSharpest_+y',
                                'reflectionSharpest_+z',
                                'reflectionSharpest_-x',
                                'reflectionSharpest_-y',
                                'reflectionSharpest_-z', 'reflectionSoft_+x',
                                'reflectionSoft_+y', 'reflectionSoft_+z',
                                'reflectionSoft_-x', 'reflectionSoft_-y',
                                'reflectionSoft_-z', 'replayIcon',
                                'rgbStripes', 'rightButton', 'robotColor',
                                'robotColorMask', 'robotIcon',
                                'robotIconColorMask', 'roundaboutLevelColor',
                                'roundaboutPreview', 'santaColor',
                                'santaColorMask', 'santaIcon',
                                'santaIconColorMask', 'scorch', 'scorchBig',
                                'scrollWidget', 'scrollWidgetGlow',
                                'settingsIcon', 'shadow', 'shadowSharp',
                                'shadowSoft', 'shield', 'shrapnel1Color',
                                'slash', 'smoke', 'softRect', 'softRect2',
                                'softRectVertical', 'sparks', 'star',
                                'startButton', 'stepRightUpLevelColor',
                                'stepRightUpPreview', 'storeCharacter',
                                'storeCharacterEaster', 'storeCharacterXmas',
                                'storeIcon', 'superheroColor',
                                'superheroColorMask', 'superheroIcon',
                                'superheroIconColorMask', 'textClearButton',
                                'thePadLevelColor', 'thePadPreview',
                                'ticketRoll', 'ticketRollBig', 'ticketRolls',
                                'tickets', 'ticketsMore', 'tipTopBGColor',
                                'tipTopLevelColor', 'tipTopPreview', 'tnt',
                                'touchArrows', 'touchArrowsActions',
                                'towerDLevelColor', 'towerDPreview',
                                'treesColor', 'trophy', 'tv', 'uiAtlas',
                                'uiAtlas2', 'upButton', 'usersButton',
                                'vrFillMound', 'warriorColor',
                                'warriorColorMask', 'warriorIcon',
                                'warriorIconColorMask', 'white',
                                'windowHSmallVMed', 'windowHSmallVSmall',
                                'wings', 'witchColor', 'witchColorMask',
                                'witchIcon', 'witchIconColorMask',
                                'wizardColor', 'wizardColorMask', 'wizardIcon',
                                'wizardIconColorMask', 'wrestlerColor',
                                'wrestlerColorMask', 'wrestlerIcon',
                                'wrestlerIconColorMask', 'zigZagLevelColor',
                                'zigzagPreview', 'zoeColor', 'zoeColorMask',
                                'zoeIcon', 'zoeIconColorMask'
                            ]
                            for i in assetnames:
                                assets.append(bs.getTexture(i))
                            # for i in nodes:
                            # if hasattr(i,'colorTexture'):
                            #if i.colorTexture not in assets:assets.append(i.colorTexture)
                            # if hasattr(i,'model'):
                            #   if i.model not in models:models.append(i.model)
                            for i in nodes:
                                if hasattr(i, 'colorTexture'):
                                    if i not in defdict:
                                        defdict.update({i: i.colorTexture})
                                    i.colorTexture = random.choice(assets)
                                # if hasattr(i,'model'):
                                #   i.model = random.choice(models)
                            if times <= choice:
                                bs.gameTimer(1000, asset)
                            else:
                                bs.gameTimer(1000, fix)

                        asset()
                    elif m == '/iceOff':
                        try:
                            activity.getMap().node.materials = [
                                bs.getSharedObject('footingMaterial')
                            ]
                            activity.getMap().isHockey = False
                        except:
                            pass
                        try:
                            activity.getMap().floor.materials = [
                                bs.getSharedObject('footingMaterial')
                            ]
                            activity.getMap().isHockey = False
                        except:
                            pass
                        for i in activity.players:
                            i.actor.node.hockey = False
                    elif m == '/maxPlayers':
                        if a == []:
                            bsInternal._chatMessage(
                                'Uso: /maxPlayers maximo de jugadores')
                        else:
                            try:
                                #bsInternal._getForegroundHostSession()._maxPlayers = int(a[0])
                                import detect
                                detect.maxPlayers = int(a[0])
                                bsInternal._setPublicPartyMaxSize(int(a[0]))
                                bsInternal._chatMessage(
                                    'Jugadores limitados a ' + str(int(a[0])))
                            except:
                                bs.screenMessage('Error!', color=(1, 0, 0))
                    elif m == '/heal':
                        if a == []:
                            for i in range(len(activity.players)):
                                if activity.players[i].getInputDevice(
                                ).getClientID() == clientID:
                                    bsInternal._getForegroundHostActivity(
                                    ).players[i].actor.node.handleMessage(
                                        bs.PowerupMessage(
                                            powerupType='health'))
                        elif a[0] == 'all':
                            for i in activity.players:
                                if i.exists() and i.actor.node.exists():
                                    i.actor.node.handleMessage(
                                        bs.PowerupMessage(
                                            powerupType='health'))
                        else:
                            try:
                                bsInternal._getForegroundHostActivity(
                                ).players[int(a[0])].actor.node.handleMessage(
                                    bs.PowerupMessage(powerupType='health'))
                            except:
                                bs.screenMessage('Error!', color=(1, 0, 0))
                    elif m == '/reflections':
                        if a == [] or len(a) < 2:
                            bsInternal._chatMessage(
                                'Uso: /reflections type(1/0) scale')
                        else:
                            rs = [int(a[1])]
                            type = 'soft' if int(a[0]) == 0 else 'powerup'
                            try:
                                bsInternal._getForegroundHostActivity().getMap(
                                ).node.reflection = type
                                bsInternal._getForegroundHostActivity().getMap(
                                ).node.reflectionScale = rs
                            except:
                                pass
                            try:
                                bsInternal._getForegroundHostActivity().getMap(
                                ).bg.reflection = type
                                bsInternal._getForegroundHostActivity().getMap(
                                ).bg.reflectionScale = rs
                            except:
                                pass
                            try:
                                bsInternal._getForegroundHostActivity().getMap(
                                ).floor.reflection = type
                                bsInternal._getForegroundHostActivity().getMap(
                                ).floor.reflectionScale = rs
                            except:
                                pass
                            try:
                                bsInternal._getForegroundHostActivity().getMap(
                                ).center.reflection = type
                                bsInternal._getForegroundHostActivity().getMap(
                                ).center.reflectionScale = rs
                            except:
                                pass
                    elif m == '/shatter':
                        if a == []:
                            bsInternal._chatMessage(
                                'Using: /shatter all o el numero de la lista')
                        else:
                            if a[0] == 'all':
                                for i in bsInternal._getForegroundHostActivity(
                                ).players:
                                    i.actor.node.shattered = int(a[1])
                            else:
                                bsInternal._getForegroundHostActivity(
                                ).players[int(
                                    a[0])].actor.node.shattered = int(a[1])
                    elif m == '/cm':
                        if a == []:
                            time = 8000
                        else:
                            time = int(a[0])

                            op = 0.08
                            std = bs.getSharedObject('globals').vignetteOuter
                            bsUtils.animateArray(
                                bs.getSharedObject('globals'), 'vignetteOuter',
                                3, {
                                    0: bs.getSharedObject(
                                        'globals').vignetteOuter,
                                    17000: (0, 1, 0)
                                })

                        try:
                            bsInternal._getForegroundHostActivity().getMap(
                            ).node.opacity = op
                        except:
                            pass
                        try:
                            bsInternal._getForegroundHostActivity().getMap(
                            ).bg.opacity = op
                        except:
                            pass
                        try:
                            bsInternal._getForegroundHostActivity().getMap(
                            ).bg.node.opacity = op
                        except:
                            pass
                        try:
                            bsInternal._getForegroundHostActivity().getMap(
                            ).node1.opacity = op
                        except:
                            pass
                        try:
                            bsInternal._getForegroundHostActivity().getMap(
                            ).node2.opacity = op
                        except:
                            pass
                        try:
                            bsInternal._getForegroundHostActivity().getMap(
                            ).node3.opacity = op
                        except:
                            pass
                        try:
                            bsInternal._getForegroundHostActivity().getMap(
                            ).steps.opacity = op
                        except:
                            pass
                        try:
                            bsInternal._getForegroundHostActivity().getMap(
                            ).floor.opacity = op
                        except:
                            pass
                        try:
                            bsInternal._getForegroundHostActivity().getMap(
                            ).center.opacity = op
                        except:
                            pass

                        def off():
                            op = 1
                            try:
                                bsInternal._getForegroundHostActivity().getMap(
                                ).node.opacity = op
                            except:
                                pass
                            try:
                                bsInternal._getForegroundHostActivity().getMap(
                                ).bg.opacity = op
                            except:
                                pass
                            try:
                                bsInternal._getForegroundHostActivity().getMap(
                                ).bg.node.opacity = op
                            except:
                                pass
                            try:
                                bsInternal._getForegroundHostActivity().getMap(
                                ).node1.opacity = op
                            except:
                               pass
                            try:
                                bsInternal._getForegroundHostActivity().getMap(
                                ).node2.opacity = op
                            except:
                                pass
                            try:
                                bsInternal._getForegroundHostActivity().getMap(
                                ).node3.opacity = op
                            except:
                                pass
                            try:
                                bsInternal._getForegroundHostActivity().getMap(
                                ).steps.opacity = op
                            except:
                                pass
                            try:
                                bsInternal._getForegroundHostActivity().getMap(
                                ).floor.opacity = op
                            except:
                                pass
                            try:
                                bsInternal._getForegroundHostActivity().getMap(
                                ).center.opacity = op
                            except:
                                pass
                            bsUtils.animateArray(
                                bs.getSharedObject('globals'), 'vignetteOuter',
                                3, {
                                    0: bs.getSharedObject(
                                        'globals').vignetteOuter,
                                    100: std
                                })

                        bs.gameTimer(time, bs.Call(off))

                    # elif m == '/help':
                    #     with open(some.helpfile) as f:
                    #         for i in f.read().split('\n'):
                    #             if i != "":
                    #                 bsInternal._chatMessage(i)
                    #     bs.screenMessage('\n' * 1000)

        except:
            #bs.printException()
            pass


c = chatOptions()


def cmd(v):
    c.opt(v[0], v[1])


def lolwa():
    bs.realTimer(1000, bs.Call(bsInternal._setPartyIconAlwaysVisible, True))
    bs.realTimer(1001, lolwa)


if some.os == 'nt':
    lolwa()
with bs.Context('UI'):
    bs.realTimer(5000, bs.Call(bsInternal._setPartyIconAlwaysVisible, True))


class FlyBox(bs.Actor):
    def __init__(self, position=(0,1,0)):
        bs.Actor.__init__(self)

        txt = bs.getTexture('rgbStripes')
        mod = bs.getModel('powerup')
        pos = (position[0], position[1]+1.5, 
                            position[2])
        self.node = bs.newNode('prop',
            delegate=self,
            attrs={
                'position':pos,
                'colorTexture':txt,
                'model':mod,
                'body':'box',
                'shadowSize':0.5,
                'reflection':'powerup',
                'reflectionScale':[1.0],
                'materials':[bs.getSharedObject('objectMaterial')]
        })

    def handleMessage(self, msg):
        if isinstance(msg, bs.OutOfBoundsMessage):
            self.handleMessage(bs.DieMessage())
        elif isinstance(msg, bs.PickedUpMessage):
            self.node.gravityScale = -1.0
        elif isinstance(msg, bs.DroppedMessage):
            self.node.gravityScale = 1.0
        elif isinstance(msg, bs.DieMessage):
            if self.node.exists(): self.node.delete()
        else: 
            bs.Actor.handleMessage(self, msg)
