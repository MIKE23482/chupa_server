# Si Estas Leyendo Esto... Gracias Por Descargar Mi Mod :3
from bsMap import *
import bsPowerup
import bsUtils
import bs

class TowerDMap2(Map):
    import towerDLevelDefs as defs
    name = 'Torre D!!'
    playTypes = ['melee', 'keepAway', 'teamFlag', 'conquest', 'kingOfTheHill']

    @classmethod
    def getPreviewTextureName(cls):
        return 'bg'

    @classmethod
    def onPreload(cls):
        data = {}
        data['model'] = bs.getModel('towerDLevel')
        data['modelBottom'] = bs.getModel('towerDLevelBottom')
        data['collideModel'] = bs.getCollideModel('towerDLevelCollide')
        data['tex'] = bs.getTexture('towerDLevelColor')
        data['bgTex'] = bs.getTexture('logo')
        # fixme should chop this into vr/non-vr sections
        data['bgModel'] = bs.getModel('thePadBG')
        data['playerWallCollideModel'] = bs.getCollideModel('towerDPlayerWall')
        data['playerWallMaterial'] = bs.Material()
        data['playerWallMaterial'].addActions(actions=(('modifyPartCollision',
                                                        'friction', 0.0)))
        # anything that needs to hit the wall can apply this material
        data['collideWithWallMaterial'] = bs.Material()
        data['playerWallMaterial'].addActions(
            conditions=('theyDontHaveMaterial',data['collideWithWallMaterial']),
            actions=(('modifyPartCollision','collide',False)))
        data['vrFillMoundModel'] = bs.getModel('stepRightUpVRFillMound')
        data['vrFillMoundTex'] = bs.getTexture('vrFillMound')
        return data

    def __init__(self):
        Map.__init__(self)
        self.powerup = bs.newNode('prop',
 attrs={'position':(-9.50, 4.0, 4.0),
  'velocity':(0,0,0),
  'model':bs.getModel('bearHead'),
  'modelScale':5.6,
  'bodyScale':5,
  'density':999999999999999999999*99999999999999,
  'damping':999999999999999999999*99999999999999,
  'gravityScale':0,
  'body':'crate',
  'reflection':'powerup',
  'reflectionScale':[0.3],									  
  'colorTexture':bs.getTexture('bearColor'),
  'materials':[bs.getSharedObject('footingMaterial')]})

        self.powerup = bs.newNode('prop',
 attrs={'position':(9.50, 4.0, 4.0),
  'velocity':(0,0,0),
  'model':bs.getModel('bearHead'),
  'modelScale':5.6,
  'bodyScale':5,
  'density':999999999999999999999*99999999999999,
  'damping':999999999999999999999*99999999999999,
  'gravityScale':0,
  'body':'crate',
  'reflection':'powerup',
  'reflectionScale':[0.3],									  
  'colorTexture':bs.getTexture('bearColor'),
  'materials':[bs.getSharedObject('footingMaterial')]})

        self.node = bs.newNode('terrain', delegate=self, attrs={
            'collideModel':self.preloadData['collideModel'],
            'model':self.preloadData['model'],
            'colorTexture':self.preloadData['tex'],
            'materials':[bs.getSharedObject('footingMaterial')]})
        self.nodeBottom = bs.newNode('terrain', delegate=self, attrs={
            'model':self.preloadData['modelBottom'],
            'lighting':False,
            'colorTexture':self.preloadData['tex']})
        bs.newNode('terrain', attrs={
            'model':self.preloadData['vrFillMoundModel'],
            'lighting':False,
            'vrOnly':True,
            'color':(0.53,0.57,0.5),
            'background':True,
            'colorTexture':self.preloadData['vrFillMoundTex']})
        self.bg = bs.newNode('terrain', attrs={
            'model':self.preloadData['bgModel'],
            'lighting':False,
            'background':True,
            'colorTexture':self.preloadData['bgTex']})
        self.playerWall = bs.newNode('terrain', attrs={
            'collideModel':self.preloadData['playerWallCollideModel'],
            'affectBGDynamics':False,
            'materials':[self.preloadData['playerWallMaterial']]})
        self.light7 = bs.newNode('shield', attrs={
            'position': (7, 3.52338, 4.0),
            'color': (0, 0, 0),
            'radius': 0.17})

        self.light7beam = bs.newNode('light', attrs={
            'position': (7, 3.50633, 4.0),
            'color': (0, 0, 0),
            'volumeIntensityScale': 1.0,
            'intensity': 0.4,
            'radius': 0.3})

        self.light6 = bs.newNode('shield', attrs={
            'position': (5.8959, 0.38269, -4.52155),
            'color': (0, 0, 0),
            'radius': 0.17})

        self.light6beam = bs.newNode('light', attrs={
            'position': (5.71476,0.56564, -4.67895),
            'color': (0, 0, 0),
            'volumeIntensityScale': 1.0,
            'intensity': 0.4,
            'radius': 0.3})

        self.light5 = bs.newNode('shield', attrs={
            'position': (3.41188, 4.38269, -5.06093),
            'color': (0, 0, 0),
            'radius': 0.17})

        self.light5beam = bs.newNode('light', attrs={
            'position': (3.54669, 4.56564, -4.90273),
            'color': (0, 0, 0),
            'volumeIntensityScale': 1.0,
            'intensity': 0.4,
            'radius': 0.3})

        self.light4 = bs.newNode('shield', attrs={
            'position': (-1.47369, 4.55083, -5.0736),
            'color': (0,0,0),
            'radius': 0.17})

        self.light4beam = bs.newNode('light', attrs={
            'position': (-1.05831, 4.73378, -4.79628),
            'color': (0, 0, 0),
            'volumeIntensityScale': 1.0,
            'intensity': 0.4,
            'radius': 0.3})

        self.light3 = bs.newNode('shield', attrs={
            'position': (-5.47391, 4.4683, -4.69703),
            'color': (0, 0, 0),
            'radius': 0.17})

        self.light3beam = bs.newNode('light', attrs={
            'position': (-5.08333, 4.56, -4.723),
            'color': (0,0,0),
            'volumeIntensityScale': 1.0,
            'intensity': 0.4,
            'radius': 0.3})

        self.light2 = bs.newNode('shield', attrs={
            'position': (-8.79521, 4.47698, 0.07394),
            'color': (0, 0, 0),
            'radius': 0.17})

        self.light2beam = bs.newNode('light', attrs={
            'position': (-8.30038, 4.65992, 0.00626),
            'color': (0, 0, 0),
            'volumeIntensityScale': 1.0,
            'intensity': 0.4,
            'radius': 0.3})

        self.light1 = bs.newNode('shield', attrs={
            'position': (-7, 3.51386, 3.5),
            'color': (0, 0, 0),
            'radius': 0.17})

        self.light1beam = bs.newNode('light', attrs={
            'position': (-7, 3.69681, 3.5),
            'color': (0, 0, 0),
            'volumeIntensityScale': 1.0,
            'intensity': 0.4,
            'radius': 0.3})

        g = bs.getSharedObject('globals')
        g.tint = (0.8, 0.8, 0.8)
        deftint = (0.8, 0.8, 0.8)
        deftint2 = (0.81, 0.81, 0.81)
        g.ambientColor = (1, 1, 1)
        g.vignetteOuter = (0.9, 0.9, 0.9)
        g.vignetteInner = (0.99, 0.99, 0.99)
        g.vrCameraOffset = (0, -4.2, -1.1)
        g.vrNearClip = 0.5
        lightsColor = (3*40, 2.82*40, 2.16*40)
        lightsBeamColor = (3, 2.82, 2.16)
        self.flag = True
        self.stdtint = deftint

        def lights_off():
            bsUtils.animateArray(self.light1, 'color', 3,
                {0: lightsColor, 3000: (0, 0, 0)})

            bsUtils.animateArray(self.light2, 'color', 3,
                {0: lightsColor, 3000: (0, 0, 0)})

            bsUtils.animateArray(self.light3, 'color', 3,
                {0: lightsColor, 3000: (0, 0, 0)})

            bsUtils.animateArray(self.light4, 'color', 3,
                {0: lightsColor, 3000: (0, 0, 0)})

            bsUtils.animateArray(self.light5, 'color', 3,
                {0: lightsColor, 3000: (0, 0, 0)})

            bsUtils.animateArray(self.light6, 'color', 3,
                {0: lightsColor, 3000: (0, 0, 0)})

            bsUtils.animateArray(self.light7, 'color', 3,
                {0: lightsColor, 3000: (0, 0, 0)})

            bsUtils.animateArray(self.light1beam, 'color', 3,
                {0: lightsBeamColor, 3000: (0, 0, 0)})

            bsUtils.animateArray(self.light2beam, 'color', 3,
                {0: lightsBeamColor, 3000: (0, 0, 0)})

            bsUtils.animateArray(self.light3beam, 'color', 3,
                {0: lightsBeamColor, 3000: (0, 0, 0)})

            bsUtils.animateArray(self.light4beam, 'color', 3,
                {0: lightsBeamColor, 3000: (0, 0, 0)})

            bsUtils.animateArray(self.light5beam, 'color', 3,
                {0: lightsBeamColor, 3000: (0, 0, 0)})

            bsUtils.animateArray(self.light6beam, 'color', 3,
                {0: lightsBeamColor, 3000: (0, 0, 0)})

            bsUtils.animateArray(self.light7beam, 'color', 3,
                {0: lightsBeamColor, 3000: (0, 0, 0)})

        def lights_on():
            if self.flag == True and self.stdtint[0] < 0.75:
                bsUtils.animateArray(self.light1, 'color', 3,
                    {0: (0, 0, 0), 3000: lightsColor})

                bsUtils.animateArray(self.light2, 'color', 3,
                    {0: (0, 0, 0), 3000: lightsColor})

                bsUtils.animateArray(self.light3, 'color', 3,
                    {0: (0, 0, 0), 3000: lightsColor})

                bsUtils.animateArray(self.light4, 'color', 3,
                    {0: (0, 0, 0), 3000: lightsColor})

                bsUtils.animateArray(self.light5, 'color', 3,
                    {0: (0, 0, 0), 3000: lightsColor})

                bsUtils.animateArray(self.light6, 'color', 3,
                    {0: (0, 0, 0), 3000: lightsColor})

                bsUtils.animateArray(self.light7, 'color', 3,
                    {0: (0, 0, 0), 3000: lightsColor})

                bsUtils.animateArray(self.light1beam, 'color', 3,
                    {0: (0, 0, 0), 3000: lightsBeamColor})

                bsUtils.animateArray(self.light2beam, 'color', 3,
                    {0: (0, 0, 0), 3000: lightsBeamColor})

                bsUtils.animateArray(self.light3beam, 'color', 3,
                    {0: (0, 0, 0), 3000: lightsBeamColor})

                bsUtils.animateArray(self.light4beam, 'color', 3,
                    {0: (0, 0, 0), 3000: lightsBeamColor})

                bsUtils.animateArray(self.light5beam, 'color', 3,
                    {0: (0, 0, 0), 3000: lightsBeamColor})

                bsUtils.animateArray(self.light6beam, 'color', 3,
                    {0: (0, 0, 0), 3000: lightsBeamColor})

                bsUtils.animateArray(self.light7beam, 'color', 3,
                    {0: (0, 0, 0), 3000: lightsBeamColor})

                self.flag = False
                def gvn():
                    self.flag = True

                bs.gameTimer(230100, gvn)
                bs.gameTimer(130000, bs.Call(lights_off))

            else: pass

        def chckr():
            if not self.stdtint == bs.getSharedObject('globals').tint:
                self.stdtint = bs.getSharedObject('globals').tint
            else:
                self.flag = True
                bs.Call(lights_off)
                self.a = 1
                bs.animateArray(bs.getSharedObject('globals'), 'tint', 3, {
                    0: deftint, 60000: deftint2, 90000: (0.6, 0.3, 0.3),
                    120000: (0.2, 0.2, 0.4), 180000: (0.21, 0.21, 0.41),
                    210000: (0.6, 0.3, 0.3), 240000: deftint
                    }, loop=True)

                self.a = bs.gameTimer(80000, bs.Call(lights_on), repeat=True)

        chckr()
        bs.gameTimer(500, bs.Call(chckr), repeat=True)

        t = bs.newNode('text', attrs={
            'text':'Mapa hecho por Rouss RRMX',
            'scale':1.2,
            'maxWidth':800,
            'position':(0,200),
            'shadow':0.5,
            'flatness':0.5,
            'hAlign':'center',
            'vAttach':'bottom'})
        c = bs.newNode('combine', owner=t, attrs={
            'size':4,
            'input0':0.3,
            'input1':0.9,
            'input2':0.0})
        bsUtils.animate(c, 'input3', {3000:0, 4000:1, 9000:1, 10000:0})
        c.connectAttr('output', t, 'color')
        bs.gameTimer(10000, t.delete)


    def _isPointNearEdge(self,p,running=False):
        # see if we're within edgeBox
        boxes = self.defs.boxes
        boxPosition = boxes['edgeBox'][0:3]
        boxScale = boxes['edgeBox'][6:9]
        boxPosition2 = boxes['edgeBox2'][0:3]
        boxScale2 = boxes['edgeBox2'][6:9]
        x = (p.x() - boxPosition[0])/boxScale[0]
        z = (p.z() - boxPosition[2])/boxScale[2]
        x2 = (p.x() - boxPosition2[0])/boxScale2[0]
        z2 = (p.z() - boxPosition2[2])/boxScale2[2]
        # if we're outside of *both* boxes we're near the edge
        return ((x < -0.5 or x > 0.5 or z < -0.5 or z > 0.5)
                and (x2 < -0.5 or x2 > 0.5 or z2 < -0.5 or z2 > 0.5))

registerMap(TowerDMap2)

class LakeFrigidMap2(Map):
    import lakeFrigidDefs as defs
    name = 'Lago Frigido!!'
    playTypes = ['melee', 'keepAway', 'teamFlag', 'race']

    @classmethod
    def getPreviewTextureName(cls):
        return 'lakeFrigidPreview'

    @classmethod
    def onPreload(cls):
        data = {}
        data['model'] = bs.getModel('lakeFrigid')
        data['modelTop'] = bs.getModel('lakeFrigidTop')
        data['modelReflections'] = bs.getModel('lakeFrigidReflections')
        data['collideModel'] = bs.getCollideModel('lakeFrigidCollide')
        data['tex'] = bs.getTexture('lakeFrigid')
        data['texReflections'] = bs.getTexture('lakeFrigidReflections')
        data['vrFillModel'] = bs.getModel('lakeFrigidVRFill')

        return data

    def __init__(self):
        Map.__init__(self)
        self.node = bs.newNode('terrain', delegate=self, attrs={
            'collideModel':self.preloadData['collideModel'],
            'model':self.preloadData['model'],
            'colorTexture':self.preloadData['tex'],
            'materials':[bs.getSharedObject('footingMaterial')]})
        bs.newNode('terrain', attrs={
            'model':self.preloadData['modelTop'],
            'lighting':False,
            'colorTexture':self.preloadData['tex']})
        bs.newNode('terrain', attrs={
            'model':self.preloadData['modelReflections'],
            'lighting':False,
            'overlay':True,
            'opacity':0.15,
            'colorTexture':self.preloadData['texReflections']})
        bs.newNode('terrain', attrs={
            'model':self.preloadData['vrFillModel'],
            'lighting':False,
            'vrOnly':True,
            'background':True,
            'colorTexture':self.preloadData['tex']})
        g = bs.getSharedObject('globals')
        g.tint = (1, 1, 1)
        g.ambientColor = (1, 1, 1)
        g.shadowOrtho = True
        g.vignetteOuter = (0.86, 0.86, 0.86)
        g.vignetteInner = (0.95, 0.95, 0.99)
        g.vrNearClip = 0.5

registerMap(LakeFrigidMap2)


class MapaInvisible(Map):
    import footballStadiumDefs as defs
    name = 'Negro Y Blanco'
    playTypes = ['melee', 'keepAway', 'teamFlag']

    @classmethod
    def getPreviewTextureName(cls):
        return 'achievementOutLine'

    @classmethod
    def onPreload(cls):
        data = {}
        data['model'] = bs.getModel("natureBackground")
        data['collideModel'] = bs.getCollideModel("natureBackgroundCollide")
        data['tex'] = bs.getTexture("natureBackgroundColor")
        data['bgModel'] = bs.getModel('thePadBG')
        data['bgTex'] = bs.getTexture('menuBG')
        return data

    
    def __init__(self):
        Map.__init__(self)
        self.node = bs.newNode('terrain', delegate=self, attrs={
            'model':self.preloadData['model'],
            'collideModel':self.preloadData['collideModel'],
            'colorTexture':self.preloadData['tex'],
            'materials':[bs.getSharedObject('footingMaterial')]})

        self.Background = bs.newNode('terrain', attrs ={
            'model':self.preloadData['bgModel'],
            'lighting':False,
            'shadow':True,
            'colorTexture':self.preloadData['bgTex']})      
        bsGlobals = bs.getSharedObject('globals')
        bsGlobals.tint = (0.52, 0.5, 0.6)
        bsGlobals.ambientColor = (255,255,255)
        bsGlobals.shadowOrtho = False
        bsGlobals.vignetteOuter = (0.76, 0.76, 0.76)
        bsGlobals.vignetteInner = (0.95, 0.95, 0.99)
        
    def _isPointNearEdge(self,p,running=False):
        x = p.x()
        z = p.z()
        xAdj = x*0.125
        zAdj = (z+3.7)*0.2
        if running:
            xAdj *= 1.4
            zAdj *= 1.4
        return (xAdj*xAdj+zAdj*zAdj > 1.0)

registerMap(MapaInvisible)