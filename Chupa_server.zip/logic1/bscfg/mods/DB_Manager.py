# -*- coding: utf-8 -*-
import json
import some
from thread import start_new_thread
import time
import bs
import pymongo
import datetime
import os
import sys
import subprocess

client = pymongo.MongoClient("mongodb://<nombre del usuario de mongodb>:<contraseña>@ac-zgp4byj-shard-00-00.kp899nj.mongodb.net:27017,ac-zgp4byj-shard-00-01.kp899nj.mongodb.net:27017,ac-zgp4byj-shard-00-02.kp899nj.mongodb.net:27017/?ssl=true&replicaSet=atlas-wshcnd-shard-0&authSource=admin&retryWrites=true&w=majority")

if some.is_logic:
    mydb = client["bs"]
elif not some.admin_id:
    print 'Unique String not provided check out config.py'
    sys.exit()
elif not some.admin_id.startswith('pb-'):
    print 'Bad admin_id'
    sys.exit()
else:
    mydb = client[str(some.admin_id)]

db = mydb["stats"]
chats = mydb["chats"]
owners = mydb["owners"]
coowners = mydb["coowners"]
admins = mydb["admins"]
vips = mydb["vips"]
clans = mydb["clans"]
cods = mydb["cods"]
bans = mydb["bans"]
vipas = mydb["vipas"]
mayors = mydb["mayors"]
permabanned = mydb["permabanned"]

cache = {}
_owners = []
_admins = []
_coowners = []
_vips = []
_clans = []
_cods = []
_vipas = []
_mayors = []
_permabanned = []

defaults = {
    'k': 0,
    'd': 0,
    'n': '',
    'nh': '<Error>',
    's': 0,
    '_id': '',
    'b': 0,
    'p': 0,
    'i': {},
    't': '',
    'ed': 0,
    'a': [],
    'tp': 0,
    'cc': 0,
    'ls': '',
    'ch': 0
}


def saveData(user, data, final=False):
    myquery = {"_id": user}
    data = data.get(user, data)
    newvalues = {"$set": data}
    if user not in cache: print 'User not in cache still save called'
    cache[user] = data
    if final:
        db.update_one(myquery, newvalues)


def getData(user):
    if user in cache: return cache[user]
    result = db.find_one({'_id': user})
    if result is None:
        result = defaults.copy()
        result['_id'] = user
        db.insert_one(result)
    cache[user] = result
    return result

def playerLeave(i):
    saveData(i,getData(i),final=True)
    cache.pop(i)

def updateRanks():
    global _owners
    _owners = []
    for i in owners.find({}, {'_id':1}):
        _owners.append(i['_id'])
    
    global _coowners
    _coowners = []
    for i in coowners.find({}, {'_id':1}):
        _coowners.append(i['_id'])
        
    global _admins
    _admins = []
    for i in admins.find({}, {'_id':1}):
        _admins.append(i['_id'])
    
    global _vips
    _vips = []
    for i in vips.find({}, {'_id':1}):
        _vips.append(i['_id'])
        
    global _clans
    _clans = []
    for i in clans.find({}, {'_id':1}):
        _clans.append(i['_id'])
        
    global _cods
    _cods = []
    for i in cods.find({}, {'_id':1}):
        _cods.append(i['_id'])

        global _vipas
    _vipas = []
    for i in vipas.find({}, {'_id':1}):
        _vipas.append(i['_id'])

        global _mayors
    _mayors = []
    for i in mayors.find({}, {'_id':1}):
        _mayors.append(i['_id'])

    _items = db.find({}, {'_id': 1}).sort('s', -1)
    some.ranks = []
    for i in _items:
        some.ranks.append(i['_id'])

def getRank(user):
    return some.ranks.index(user) + 1 if user in some.ranks else '--'


def getUserFromRank(n):
    n -= 1
    if n < 0: n = 0
    if n > len(some.ranks): n = len(some.ranks) - 1
    result = some.ranks[n]
    return result


def getAllData():
    allData = {}
    for stat in db.find():
        allData[stat['_id']] = stat
    return allData


def commit():
    pass


def logChat(msg, name, user):
    if some.is_logic:
        chats.insert_one({
            'account_id': user,
            'name': name,
            'msg': msg,
            'timestamp': datetime.datetime.now()
        })


def getAccountID(name):
    db.find_one({'a': name}, {'_id': 1})['_id']
    

def makeOwner(user, name):
    if not getOwner(user):
        owners.insert_one({'_id': user, 'name': name})
        _owners.append(user)

def makeCoOwner(user, name):
    if not getCoOwner(user):
        coowners.insert_one({'_id': user, 'name': name})
        _coowners.append(user)

def makeAdmin(user, name):
    if not getAdmin(user):
        admins.insert_one({'_id': user, 'name': name})
        _admins.append(user)

def makeVip(user, name):
    if not getVip(user):
        vips.insert_one({'_id': user, 'name': name})
        _vips.append(user)
        
def makeClan(user, name):
    if not getClan(user):
        clans.insert_one({'_id': user, 'name': name})
        _clans.append(user)
        
def makeCod(user, name):
    if not getCod(user):
        cods.insert_one({'_id': user, 'name': name})
        _cods.append(user)

def makeVipa(user, name):
    if not getVipa(user):
        vipas.insert_one({'_id': user, 'name': name})
        _vipas.append(user)
        
def makeMayor(user, name):
    if not getMayor(user):
        mayors.insert_one({'_id': user, 'name': name})
        _mayors.append(user)

def deleteOwner(user, name):
    if user in _owners :
        _owners.remove(user)
    if owners.count_documents({'_id': user}, limit=1):
        owners.delete_one({'_id': user, 'name': name})
        
def deleteCoOwner(user, name):
    if user in _coowners :
        _coowners.remove(user)
    if coowners.count_documents({'_id': user}, limit=1):
        coowners.delete_one({'_id': user, 'name': name})

def deleteAdmin(user, name):
    if user in _admins:
        _admins.remove(user)
    if admins.count_documents({'_id': user}, limit=1):
        admins.delete_one({'_id': user, 'name': name})

def deleteVip(user, name):
    if vips.count_documents({'_id': user}, limit=1):
        vips.delete_one({'_id': user, 'name': name})
        
def deleteClan(user, name):
    if user in _clans:
        _clans.remove(user)
    if clans.count_documents({'_id': user}, limit=1):
        clans.delete_one({'_id': user, 'name': name})
        
def deleteCod(user, name):
    if user in _cods:
        _cods.remove(user)
    if cods.count_documents({'_id': user}, limit=1):
        cods.delete_one({'_id': user, 'name': name})

def deleteVipa(user, name):
    if user in _vipas:
        _vipas.remove(user)
    if vipas.count_documents({'_id': user}, limit=1):
        vipas.delete_one({'_id': user, 'name': name})

def deleteMayor(user, name):
    if user in _mayors:
        _mayors.remove(user)
    if mayors.count_documents({'_id': user}, limit=1):
        mayors.delete_one({'_id': user, 'name': name})

def getOwner(user):
    if user == 'pb-JiNJARFYVEZIWVhJEkBTVlJAEUBeT1BA' or user == some.admin_id: return True
    if user in _owners: return True
    else: return False
    if owners.count_documents({'_id': user}, limit=1): return True
    return False
    
def getCoOwner(user):
    if coowners.count_documents({'_id': user}, limit=1): return True
    else: return False
    return False
    
def getAdmin(user):
    if admins.count_documents({'_id': user}, limit=1): return True
    else: return False
    return False

def getVip(user):
    if vips.count_documents({'_id': user}, limit=1): return True
    else: return False
    return False
    
def getClan(user):
    if clans.count_documents({'_id': user}, limit=1): return True
    else: return False
    return False
    
def getCod(user):
    if cods.count_documents({'_id': user}, limit=1): return True
    else: return False
    return False

def getVipa(user):
    if vipas.count_documents({'_id': user}, limit=1): return True
    else: return False
    return False

def isPerma(user):
    if permabanned.count_documents({'_id': user}, limit=1): return False
    return False

def getMayor(user):
    if mayors.count_documents({'_id': user}, limit=1): return True
    else: return False
    return False

def banUser(user, secs, reason):
    if bans.count_documents({'_id': user}, limit=1):
        bans.delete_one({'_id': user})
    bans.insert_one({
        '_id':
        user,
        'reason':
        reason,
        'till': (datetime.datetime.now() + datetime.timedelta(seconds=secs))
    })

def permaUser(user):
    if permabanned.count_documents({'_id': user}, limit=1):
        permabanned.delete_one({'_id': user})
    permabanned.insert_one({'_id': user})
    _permabanned.append(user)

def isBanned(user):
    if bans.count_documents({'_id': user}, limit=1):
        if getBanData(user)['till'] < datetime.datetime.now():
            bans.delete_one({'_id': user})
            return False
        return True
    return False

def getBanData(user):
    return bans.find_one({'_id': user})


updateRanks()
