import bs, bsInternal, pytz, bsGame
import datetime
#by smooth
class textonmap:

	def __init__(self):
		self._date_and_time()

	def _date_and_time(self):
		self.date_and_time_node = bs.newNode('text',
			attrs = {
			'text': "Fuck",
			'vAttach': 'bottom',
            'vAlign': 'bottom',
            'hAttach': 'right',
            'hAlign': 'right',
            'flatness': 1.0,
            'opacity': 1.0,
            'shadow': 0.5,
            'color': (0.5, 0.5, 0.5, 0.7),
            'scale': 0.7,
            'position': (-75, 0)})
		def update():
			#activity=bsInternal._getForegroundHostActivity()
			#with bs.Context(activity):
			zone = pytz.timezone('America/Bogota')
			self.date_and_time_node.text = str(datetime.datetime.now(zone).strftime('%d-%m-%Y'))
		self.timer = bs.Timer(1, update, repeat=True)
		update()

orignBegin = bsGame.GameActivity.onBegin 

def new_begin(self):

	orignBegin(self)

	textonmap()

bsGame.GameActivity.onBegin = new_begin
	