
import bs
from bsMap import Map, registerMap
import bsUtils
import bsPowerup
import random
import bdUtils

class Map9:
    points = {}
    boxes = {}
    boxes['areaOfInterestBounds'] = (0.3544110667, -1.493562578, -2.518391331) + (0.0, -15.0, 0.0) + (16.64754831, 15.06138989, 18.5029888)
    points['ffaSpawn1'] = (6.5,4.0,-2.0) + (0.1,0.1,1.0)
    points['ffaSpawn2'] = (-6.5,-1.0,3.0) + (0.1,0.1,1.0)
    points['ffaSpawn3'] = (6.5,-1.0,3.0) + (0.1,0.1,1.0) 
    points['ffaSpawn4'] = (-6.5,4.0,-2.0) + (0.1,0.1,1.0)
    points['flag1'] = (-7.026110145, 4.308759233,5.6)
    points['flag2'] = (7.632557137, 4.366002373, -6.287969342)
    points['flagDefault'] = (0.4611826686, 4.382076338, 3.680881802)
    boxes['levelBounds'] = (0.0, 0.7956858119, -0.4689020853) + (0.0, 0.0, 0.0) + (40.16182389, 12.18696164, 40.52869693)
    points['powerupSpawn1'] = (-6.166594349, 5.281834349, -6.427493781)
    points['powerupSpawn2'] = (6.426873526, 5.342460464, -6.329745237)
    points['powerupSpawn3'] = (-6.201686731, 2.123385835, 2.4400721376)
    points['powerupSpawn4'] = (6.758924722, 2.123385835, 2.3494054559)
    points['shadowLowerBottom'] = (-0.2912522507, 2.020798381, 5.341226521)
    points['shadowLowerTop'] = (-0.2912522507, 3.206066063, 5.341226521)
    points['shadowUpperBottom'] = (-0.2912522507, 6.062361813, 5.341226521)
    points['shadowUpperTop'] = (-0.2912522507, 9.827201965, 5.341226521)
    points['spawn1'] = (-9,0.5,-3) + (1.0,0.1,1.0)
    points['spawn2'] = (9,0.5,-3) + (1.0,0.1,1.0)
    points['tnt1'] = (0.4599593402, 4.044276501, -6.573537395)
##Create Empty Map
class Map9(Map):
    from Map9 import Map9 as defs
    name = 'Map9'
    playTypes = ['test', 'melee']

    @classmethod
    def getPreviewTextureName(cls):
        return 'rampageBGColor'

    @classmethod
    def onPreload(cls):
        data = {}
        data['model'] = bs.getModel('thePadLevel')
        data['modelBottom'] = bs.getModel('thePadLevelBottom')
        data['modelBG'] = bs.getModel('doomShroomBG')
        #data['bgVRFillModel'] = bs.getModel('natureBackgroundVRFill')
        data['collideModel'] = bs.getCollideModel('thePadLevelCollide')
        data['tex'] = bs.getTexture('thePadLevelColor')
        data['modelBGTex'] = bs.getTexture('achievementFlawlessVictory')
        #data['collideBG'] = bs.getCollideModel('natureBackgroundCollide')
        data['railingCollideModel'] = bs.getCollideModel('thePadLevelBumper')
        #data['bgMaterial'] = bs.Material()
        #data['bgMaterial'].addActions(actions=('modifyPartCollision',
                                               #'friction', 10.0))
        return data

    def __init__(self):
        Map.__init__(self)
        self.locs=[]
        self.regions=[]
        self.explo=[]
        self.collision = bs.Material()
        self.collision.addActions(
            actions=(('modifyPartCollision', 'collide', True)))
        self.foo = bs.newNode('terrain', attrs={
            'model':self.preloadData['modelBG'],
            'lighting':False,
            'reflection':'powerup',
            'reflectionScale':[1],
            'colorTexture':self.preloadData['modelBGTex']})
        # self.bottom = bs.newNode('terrain', attrs={
        #     'model':self.preloadData['modelBottom'],
        #     'lighting':False,
        #     'colorTexture':self.preloadData['tex']})
        # bs.newNode('terrain', attrs={
        #     'model':self.preloadData['bgVRFillModel'],
        #     'lighting':False,
        #     'vrOnly':True,
        #     'background':True,
        #     #'colorTexture':self.preloadData['modelBGTex']})
        # self.bgCollide = bs.newNode('terrain', attrs={
        #     'collideModel':self.preloadData['collideBG'],
        #     'materials':[bs.getSharedObject('footingMaterial'),
        #                  self.preloadData['bgMaterial'],
        #                  bs.getSharedObject('deathMaterial')]})
        # self.railing = bs.newNode('terrain', attrs={
        #     'collideModel':self.preloadData['railingCollideModel'],
        #     'materials':[bs.getSharedObject('railingMaterial')],
        #     'bumper':True})
        po3Dict = [
                   {'pos': (0.0,-1.0,2.5),'size': (18.0,1.0,8.0)},
                   {'pos': (0.0,4.0,-3.5),'size': (18.0,1.0,8.0)}


                
             
        ]
        for a, map in enumerate(po3Dict):
            self.locs.append(bs.newNode('locator',
                attrs={'shape': 'box',
                       'position': po3Dict[a]['pos'],
                       'color': (2, 0, 2),
                       'opacity': 0.1,
                       'drawBeauty': True,
                       'size': po3Dict[a]['size'],
                       'additive': False}))
            self.regions.append(bs.newNode('region',
                attrs={'scale': tuple(po3Dict[a]['size']),
                       'type': 'box',
                       'materials': [self.collision, bs.getSharedObject('footingMaterial')]}))
            self.locs[-1].connectAttr('position', self.regions[-1], 'position')

        possDict = [
                   {'pos': (10,4.0,-4.0),'size': (2.0,1.0,2.0)},
                   {'pos': (-10,-1.0,3.0),'size': (2.0,1.0,2.0)}

                
             
        ]
        for a, map in enumerate(possDict):
            self.locs.append(bs.newNode('locator',
                attrs={'shape': 'box',
                       'position': possDict[a]['pos'],
                       'color': (0.0, 6, 0),
                       'opacity': 0.1,
                       'drawBeauty': True,
                       'size': possDict[a]['size'],
                       'additive': False}))
            self.regions.append(bs.newNode('region',
                attrs={'scale': tuple(possDict[a]['size']),
                       'type': 'box',
                       'materials': [self.collision, bs.getSharedObject('footingMaterial')]}))
            self.locs[-1].connectAttr('position', self.regions[-1], 'position')
 
        posDict = [
                   {'pos': (-10,4.0,-4.0),'size': (2.0,1.0,2.0)},
                   {'pos': (10,-1.0,3.0),'size': (2.0,1.0,2.0)}

                
             
        ]
        for a, map in enumerate(posDict):
            self.locs.append(bs.newNode('locator',
                attrs={'shape': 'box',
                       'position': posDict[a]['pos'],
                       'color': (0, 2, 2),
                       'opacity': 0.1,
                       'drawBeauty': True,
                       'size': posDict[a]['size'],
                       'additive': False}))
            self.regions.append(bs.newNode('region',
                attrs={'scale': tuple(posDict[a]['size']),
                       'type': 'box',
                       'materials': [self.collision, bs.getSharedObject('footingMaterial')]}))
            self.locs[-1].connectAttr('position', self.regions[-1], 'position')
        
        g = bs.getSharedObject('globals')
        g.tint = (1,1,1)
        g.ambientColor = (1.3, 1.2, 1.0)
        g.vignetteOuter = (0.57, 0.57, 0.57)
        g.vignetteInner = (0.9, 0.9, 0.9)
        g.vrCameraOffset = (0, -0.8, -1.1)
        g.vrNearClip = 0.50
        def path():
                p = bs.newNode('prop', attrs={'position':"position",'body':'sphere','model':bs.getModel('bomb'),'colorTexture':bs.getTexture('logo'),'density':999999999999999999999*99999999999999,'damping':999999999999999999999*99999999999999,'gravityScale':50,'shadowSize':0.0,'materials':[bs.getSharedObject('footingMaterial'),bs.getSharedObject('footingMaterial')]})
                bsUtils.animateArray(p,"position",3,{0:(0,-4,-2.5),2000:(0,-3,-2.5),3000:(-20,-3,-2.5),120000:(0,-3,-2.5),121500:(0,23,-2.5)},loop = True)                
                bs.animate(p,"modelScale",{0:18.0,1000:10.0})
        bs.gameTimer(1,bs.Call(path))
        bs.getSharedObject('globals').slowMotion = bs.getSharedObject('globals').slowMotion == False
        bdUtils.Portal(position1=(10,4.0,-4.0),position2=(-10,-1.0,3.0),color=(3, 0, 9/2))
        bdUtils.Portal(position1=(-10,4.0,-4.0),position2=(10,-1.0,3.0),color=(3, 0, 9/2))
        m = 1
        s = 2000
        bsUtils.animateArray(bs.getSharedObject('globals'), 'ambientColor', 3, {0: (1 * m, 0, 0), s: (0, 1 * m, 0), s * 2: (0, 0, 1 * m), s * 3: (1 * m, 0, 0)}, True)
        
        self.logo = bs.newNode(
            'image',
            attrs={
                'texture': bs.getTexture('bg'),
                'scale': (1500, 1500),
                'color':(0,0,0),
                'rotate': 0.0,
                'position': (0,0),
                'opacity':0.15,
                'tiltTranslate': -0.05,
                'absoluteScale': True
                    })
        bs.animate(self.logo,"opacity",{0: 1, 1200:1 ,1500: 0})

        t = bs.newNode('text', attrs={
            'text':'loading...',
            'scale':4,
            'maxWidth':0,
            'position':(0,300),
            'shadow':0.5,
            'opacity':0.15,
            'flatness':0.5,
            'hAlign':'center',
            'vAttach':'bottom'})
        bs.animate(t,"opacity",{0: 1, 1200:1 ,1500: 0})

        t = bs.newNode('text', attrs={
            'text':'by:Rouss RRMX <3',
            'scale':1.5,
            'maxWidth':0,
            'position':(0,180),
            'shadow':0.5,
            'opacity':0.15,
            'flatness':0.5,
            'hAlign':'center',
            'vAttach':'bottom'})
        bs.animate(t,"opacity",{0: 1, 1200:1 ,1500: 0})
        multiColor = {0:((0+random.random()*1.0),(0+random.random()*1.0),(0+random.random()*1.0)),500:((0+random.random()*1.0),(0+random.random()*1.0),(0+random.random()*1.0)),1000:((0+random.random()*1.0),(0+random.random()*1.0),(0+random.random()*1.0)),1500:((0+random.random()*1.0),(0+random.random()*1.0),(0+random.random()*1.0)),2000:((0+random.random()*1.0),(0+random.random()*1.0),(0+random.random()*1.0)),2500:((0+random.random()*1.0),(0+random.random()*1.0),(0+random.random()*1.0)),3000:((0+random.random()*1.0),(0+random.random()*1.0),(0+random.random()*1.0)),3500:((0+random.random()*1.0),(0+random.random()*1.0),(0+random.random()*1.0))}
        bsUtils.animateArray(t,'color',3,multiColor,True)
registerMap(Map9)